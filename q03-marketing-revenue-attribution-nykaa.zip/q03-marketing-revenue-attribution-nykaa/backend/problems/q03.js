// Q3: Marketing-to-Revenue Attribution - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const CH=['Search','Social','Email','Display','Referral'],P={Search:[.5,.7,.6,.55],Social:[.7,.4,.35,.3],Email:[.45,.75,.7,.7],Display:[.35,.5,.4,.4],Referral:[.4,.8,.75,.8]},ST=['Exposed','Lead','Qualified lead','Opportunity','Customer'];
const r=R(5),J=[];
for(let i=0;i<3000;i++){const n=1+Math.floor(r()*5),t=[];for(let a=0;a<n;a++)t.push(CH[Math.floor(Math.pow(r(),1.3)*5)]);
 const bo=Math.min(.12,n*.03);let s=0;for(let q=0;q<4;q++){const p=Math.min(.95,mean(t.map(c=>P[c][q]))+bo-.05);if(r()<p)s++;else break}J.push({t,s,v:.6+r()*.8})}
return {CH,P,ST,J};
}
