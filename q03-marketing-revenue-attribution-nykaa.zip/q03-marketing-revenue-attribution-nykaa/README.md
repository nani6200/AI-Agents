# Q3. Marketing-to-Revenue Attribution (Nykaa)
**Problem:** Many leads, little revenue; which channel and which funnel stage deserve attention?
**Data:** 3,000 customer journeys with 1-5 touches across Search, Social, Email, Display, Referral; each journey reaches stage 0-4 (Exposed, Lead, Qualified lead, Opportunity, Customer).
**Algorithm: funnel leakage + five attribution models**
1. Count journeys reaching each stage; stage-to-stage drop = leak.
2. Value of a leak = leaked journeys × downstream conversion × deal value × 0.8 (see `run()` in `app.js`).
3. Attribution weights for a journey with n touches: first touch (all to touch 1); last touch; linear (1/n each); time decay (weight ∝ 2^(position-n+1)); position-based (40% first, 40% last, 20% shared by the middle).
4. Credit per channel is summed twice: for leads (1 per journey) and for customers (deal value × journey value).
5. Gap ratio per channel = share of revenue credit ÷ share of lead credit. Below 1 = brings leads that do not become revenue.
6. **Optimizer:** fix first the stage with the largest value from a 5-point conversion gain: `entrants × 0.05 × downstream conversion × deal value × 0.8`.

**Code:** `backend/problems/q03.js` (journey generator); attribution weights and ranking in `app.js`.


**AI component:** Multi-touch attribution + funnel-leak ranking

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q03.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q03-marketing-revenue-attribution-nykaa-standalone.html` also opens directly in a browser with no server.
