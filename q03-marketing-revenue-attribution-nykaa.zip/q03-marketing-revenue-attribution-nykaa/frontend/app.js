import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {CH,P,ST,J}=await (await fetch('/api/q03/model')).json();
const W={first:n=>n.map((_,i)=>i?0:1),last:n=>n.map((_,i)=>i==n.length-1?1:0),lin:n=>n.map(()=>1/n.length),
 td:n=>{const a=n.map((_,i)=>Math.pow(2,i-n.length+1)),s=a.reduce((x,y)=>x+y);return a.map(v=>v/s)},
 pos:n=>n.length==1?[1]:n.length==2?[.5,.5]:n.map((_,i)=>i==0||i==n.length-1?.4:.2/(n.length-2))};
function credit(m,minS,dv){const o={};CH.forEach(c=>o[c]=0);J.filter(j=>j.s>=minS).forEach(j=>{const w=W[m](j.t);j.t.forEach((c,i)=>o[c]+=w[i]*(minS==4?dv*j.v:1))});return o}
function run(){
 const m=$('am').value,dv=+$('dv').value,cnt=ST.map((_,s)=>J.filter(j=>j.s>=s).length);
 const cust=cnt[4],rev=J.filter(j=>j.s>=4).reduce((s,j)=>s+dv*j.v,0)/1000;
 $('kpi').innerHTML=kp([['Journeys',J.length.toLocaleString()],['Leads',cnt[1].toLocaleString()],['Customers',cust.toLocaleString()],['Revenue','$'+Math.round(rev).toLocaleString()+'k'],['Lead to customer',(cust/cnt[1]*100).toFixed(1)+'%']]);
 const lost=ST.slice(1).map((s,i)=>({s:ST[i]+' to '+s,l:cnt[i]-cnt[i+1],pct:(1-cnt[i+1]/cnt[i])*100,val:(cnt[i]-cnt[i+1])*(cust/cnt[i+1])/cnt[i]*dv*.8/1000}));
 const mx=Math.max(...lost.map(x=>x.l));$('fun').innerHTML=lost.map(x=>row(x.s,x.l,mx,x.pct.toFixed(0)+'% lost',x.val===Math.max(...lost.map(y=>y.val))?'n':'b')).join('')+'<p class="note">Red marks the stage where the most expected revenue leaks.</p>';
 const L=credit(m,1,dv),Rv=credit(m,4,dv),tl=Object.values(L).reduce((a,b)=>a+b),tr=Object.values(Rv).reduce((a,b)=>a+b);
 $('lr').innerHTML=CH.map(c=>row(c,L[c]/tl*100,45,'leads '+(L[c]/tl*100).toFixed(0)+'%','g')+row('',Rv[c]/tr*100,45,'revenue '+(Rv[c]/tr*100).toFixed(0)+'%',Rv[c]/tr<.8*L[c]/tl?'n':'b')).join('');
 const all=Object.keys(W).map(k=>[k,credit(k,4,dv)]);const nm={first:'First touch',last:'Last touch',lin:'Linear',td:'Time decay',pos:'Position'};
 $('cmp').innerHTML=tb(['Channel',...all.map(a=>nm[a[0]])],CH.map(c=>[c,...all.map(a=>Math.round(a[1][c]/1000).toLocaleString())]));
 const gap=CH.map(c=>({c,x:(Rv[c]/tr)/(L[c]/tl)})).sort((a,b)=>a.x-b.x),wl=lost.sort((a,b)=>b.val-a.val)[0];
 $('dx').innerHTML=ul(['Biggest leak: <b>'+wl.s+'</b>, losing '+wl.l.toLocaleString()+' journeys ('+wl.pct.toFixed(0)+'%).','<b>'+gap[0].c+'</b> brings '+(L[gap[0].c]/tl*100).toFixed(0)+'% of lead credit but only '+(Rv[gap[0].c]/tr*100).toFixed(0)+'% of revenue credit. Its leads are low quality; tighten targeting or qualify earlier.','<b>'+gap[4].c+'</b> converts best relative to its lead volume. Test shifting budget toward it.','Credit for one channel swings by up to '+Math.round(Math.max(...CH.map(c=>Math.max(...all.map(a=>a[1][c]))-Math.min(...all.map(a=>a[1][c]))))/1000)+'k across models, so judge channels on more than one model.'])}
['am','dv'].forEach(i=>$(i).oninput=run);$('am').onchange=run;run();
/* AI optimizer */
function OPT(a){const dv=+$('dv').value,cnt=ST.map((_,s)=>J.filter(j=>j.s>=s).length),cu=cnt[4];
const g=ST.slice(1).map((s,i)=>({s:ST[i]+' to '+s,v:cnt[i]*.05*(cu/cnt[i+1])*dv*.8/1000})).sort((x,y)=>y.v-x.v);
$('optout').innerHTML='Fix first: <b>'+g[0].s+'</b>, worth about <b>$'+Math.round(g[0].v)+'k</b> for each 5 points of conversion gained. Next: '+g.slice(1,3).map(x=>x.s+' ($'+Math.round(x.v)+'k)').join(', ')+'.'}
$('optbtn').onclick=()=>OPT(true);OPT(false);
