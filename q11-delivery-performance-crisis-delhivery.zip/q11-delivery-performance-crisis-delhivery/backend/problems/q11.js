// Q11: Delivery Performance Crisis - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const FN=['Split shipment (stock in 2 warehouses)','Understaffed shift','Rural zone','Carrier B','Peak hour','Warehouse 3'],r=R(63),O=[];
for(let i=0;i<4000;i++){const x=[r()<.22?1:0,r()<.3?1:0,r()<.25?1:0,r()<.4?1:0,r()<.35?1:0,r()<.25?1:0],z=-2.1+1.5*x[0]+1.0*x[1]+.8*x[2]+.7*x[3]+.4*x[4]+.5*x[5];O.push({x,y:r()<sig(z)?1:0})}
const w=logit(O.map(o=>o.x),O.map(o=>o.y),400,.8),late=mean(O.map(o=>o.y));
function gini(a){const n=a.length;if(!n)return 0;const p=a.filter(o=>o.y).length/n;return 2*p*(1-p)}
function tree(a,d){const n=a.length,p=a.filter(o=>o.y).length/n;if(d==3||n<150)return{n,p};let b=-1,bj=-1;for(let j=0;j<6;j++){const y=a.filter(o=>o.x[j]),m=a.filter(o=>!o.x[j]);if(y.length<50||m.length<50)continue;const g=gini(a)-(y.length*gini(y)+m.length*gini(m))/n;if(g>b){b=g;bj=j}}
 if(bj<0)return{n,p};return{n,p,j:bj,y:tree(a.filter(o=>o.x[bj]),d+1),m:tree(a.filter(o=>!o.x[bj]),d+1)}}
const T=tree(O,0);
return {FN,O,w,late,T};
}
