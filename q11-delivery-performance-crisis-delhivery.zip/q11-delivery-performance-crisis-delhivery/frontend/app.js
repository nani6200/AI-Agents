import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {FN,O,w,late,T}=await (await fetch('/api/q11/model')).json();
const show=(t,l)=>t.j===undefined?'':'<ul><li><b>'+FN[t.j]+'</b><ul><li>yes: '+Math.round(t.y.p*100)+'% late ('+t.y.n+')'+show(t.y)+'</li><li>no: '+Math.round(t.m.p*100)+'% late ('+t.m.n+')'+show(t.m)+'</li></ul></li></ul>';
function run(){const s=[1,2,3].map(i=>+$('s'+i).value/100),lc=+$('lc').value;[1,2,3].forEach(i=>$('a'+i).textContent=Math.round(s[i-1]*100)+'%');
 const ex=FN.map((f,j)=>{const a=O.filter(o=>o.x[j]),b=O.filter(o=>!o.x[j]);return{f,e:Math.max(0,(mean(a.map(o=>o.y))-mean(b.map(o=>o.y)))*a.length),r:mean(a.map(o=>o.y)),n:a.length}}).sort((a,b)=>b.e-a.e);
 $('fx').innerHTML=ex.map(e=>row(e.f.split(' (')[0],e.e,ex[0].e,Math.round(e.e)+' orders',e===ex[0]?'n':'b')).join('')+'<p class="note">Late rate when present vs absent, times orders affected.</p>';$('tr').innerHTML='<p>All orders: <b>'+Math.round(T.p*100)+'% late</b> ('+T.n+')</p>'+show(T);
 const base=mean(O.map(o=>pred(w,o.x))),nw=mean(O.map(o=>pred(w,[o.x[0]*(1-s[0]),o.x[1]*(1-s[1]),o.x[2],o.x[3]*(1-s[2]),o.x[4],o.x[5]]))),sav=(base-nw)*O.length;
 $('rs').innerHTML=kp([['Late rate now',(base*100).toFixed(1)+'%'],['Late rate after',(nw*100).toFixed(1)+'%',nw<base?'pos':''],['Late orders avoided (per 4,000)',Math.round(sav)],['Saving','$'+Math.round(sav*lc).toLocaleString()]]);
 $('kpi').innerHTML=kp([['Orders analysed',O.length.toLocaleString()],['Late rate',(late*100).toFixed(1)+'%','neg'],['Biggest cause',ex[0].f.split(' (')[0]],['Late orders it explains',Math.round(ex[0].e)]]);
 $('ac').innerHTML=ul(['<b>'+ex[0].f+'</b> is the largest source of lateness ('+Math.round(ex[0].r*100)+'% late when present). Fix this first.','Capacity is not the problem; <b>'+ex[1].f.split(' (')[0].toLowerCase()+'</b> and <b>'+ex[2].f.split(' (')[0].toLowerCase()+'</b> follow. Schedule staff to order volume by hour, not by a flat roster.','Hold orders for a few hours to ship from one warehouse when a split would add a day.','Review carrier B service terms or shift lanes where it underperforms.'])}
[1,2,3].forEach(i=>$('s'+i).oninput=run);$('lc').oninput=run;run();
/* AI optimizer */
function OPT(a){const lcost=+$('lc').value,cs=[150,250,100],base=mean(O.map(o=>pred(w,o.x)));let b=null;
for(const a1 of [0,25,50,75,100])for(const a2 of [0,25,50,75,100])for(const a3 of [0,25,50,75,100]){const nw=mean(O.map(o=>pred(w,[o.x[0]*(1-a1/100),o.x[1]*(1-a2/100),o.x[2],o.x[3]*(1-a3/100),o.x[4],o.x[5]]))),net=(base-nw)*O.length*lcost-(a1*cs[0]+a2*cs[1]+a3*cs[2])/10;if(!b||net>b.net)b={a1,a2,a3,net,nw}}
$('optout').innerHTML='Best mix: remove <b>'+b.a1+'%</b> of split shipments, fix <b>'+b.a2+'%</b> of understaffed shifts, move <b>'+b.a3+'%</b> of carrier B volume. Late rate falls to '+(b.nw*100).toFixed(1)+'%. Program costs assumed: $150, $250 and $100 per 10% of each fix.';if(a){$('s1').value=b.a1;$('s2').value=b.a2;$('s3').value=b.a3;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
