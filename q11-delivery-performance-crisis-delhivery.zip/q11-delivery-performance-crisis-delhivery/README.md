# Q11. Delivery Performance Crisis (Delhivery)
**Problem:** Delays rise although capacity looks fine.
**Data:** 4,000 orders with six yes/no conditions (split shipment, understaffed shift, rural zone, carrier B, peak hour, warehouse 3) and a late flag.
**Algorithm: logistic model + decision tree + what-if**
1. Logistic regression (400 iterations, learning rate 0.8) on the binary conditions.
2. Impact per condition = `(late rate with - late rate without) × orders with`.
3. Decision tree (Gini impurity `2p(1-p)`), best binary split by impurity reduction, depth ≤ 3, at least 150 orders per node and 50 per child. Printed as the root-cause tree.
4. What-if: reduce three conditions by chosen percentages, re-score all orders, `late orders avoided = (baseline - new) × orders`, value = avoided × cost per late order.
5. **Optimizer:** grid search over 0/25/50/75/100% for each of the three fixes; net = value - programme cost ($150, $250, $100 per 10% of each fix).

**Code:** `backend/problems/q11.js`; what-if in `app.js`.


**AI component:** Logistic model + decision tree + fix-mix optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q11.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q11-delivery-performance-crisis-delhivery-standalone.html` also opens directly in a browser with no server.
