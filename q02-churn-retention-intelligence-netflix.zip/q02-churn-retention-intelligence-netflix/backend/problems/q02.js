// Q2: Customer Churn and Retention Intelligence - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const r=R(11),F=['On monthly plan','Tenure (months)','Logins per month','Support tickets','Used a discount'];
const D=[];for(let i=0;i<900;i++){const mo=r()<.55?1:0,te=1+Math.floor(r()*47),lg=Math.max(0,Math.round(18-te*.05-mo*3+N(r)*6)),tk=Math.max(0,Math.round(N(r)*1.5+(r()<.2?3:0))),ds=r()<.3?1:0,z=-1.1+1.1*mo-.035*te-.09*lg+.45*tk+.9*ds+N(r)*.5;D.push({id:'C'+(1000+i),x:[mo,te,lg,tk,ds],mrr:19+Math.round(r()*80),y:r()<sig(z)?1:0})}
const tr=D.slice(0,630),te=D.slice(630),mu=F.map((_,j)=>mean(tr.map(d=>d.x[j]))),sg=F.map((_,j)=>sd(tr.map(d=>d.x[j])));
const Z=d=>d.x.map((v,j)=>(v-mu[j])/sg[j]),w=logit(tr.map(Z),tr.map(d=>d.y));
const A=auc(te.map(d=>pred(w,Z(d))),te.map(d=>d.y));
D.forEach(d=>{d.z=Z(d);d.p=pred(w,d.z);d.c=d.z.map((v,j)=>w[j]*v)});
const CAUSE=[
['Flexible-plan drifters','Monthly billing makes leaving easy','Offer a discounted annual plan before the next renewal date.'],
['Early-life drop-off','Short tenure, not yet attached','Run a 90-day onboarding journey with a guided first win and a check-in call.'],
['Disengaged users','Logins have dried up','Trigger a re-activation email and in-app tips when logins fall for 2 weeks.'],
['Support-frustrated','Repeated tickets without resolution','Escalate to a named agent and follow up within 24 hours; offer a service credit.'],
['Discount-dependent','Joined on a deal, price-sensitive','Do not deepen the discount; show value with a usage summary and loyalty perks.']];
const sgn=[1,-1,-1,1,1];
return {F,D,tr,te,mu,sg,w,A,CAUSE,sgn};
}
