# Q2. Churn and Retention Intelligence (Netflix)
**Problem:** Subscribers churn faster than marketing replaces them.
**Data:** 900 subscribers; features: monthly plan, tenure, logins/month, support tickets, used a discount; label = churned.
**Algorithm: logistic regression + risk threshold sweep**
1. Split 630 train / 270 test. Standardize features with train mean and standard deviation.
2. Fit logistic regression by gradient descent. Report AUC on the 270 unseen customers.
3. Score every customer: churn probability `p`. Per-feature contribution = `weight × standardized value`.
4. At-risk list = customers with `p >= threshold`. Each customer's **cause** = the feature with the largest positive contribution; each cause maps to a retention play (annual plan offer, onboarding journey, re-activation, escalation, no deeper discount).
5. Value at risk = Σ `p × monthly revenue × 12`; expected saving = that × play success rate; cost = contacts × cost per contact.
6. **Optimizer:** sweep the threshold 20%-80% in 5% steps and keep the one with the highest `saving - cost`.

**Code:** model in `backend/problems/q02.js`; optimizer in `frontend/q02-*/app.js`.


**AI component:** Logistic regression churn model + threshold optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q02.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q02-churn-retention-intelligence-netflix-standalone.html` also opens directly in a browser with no server.
