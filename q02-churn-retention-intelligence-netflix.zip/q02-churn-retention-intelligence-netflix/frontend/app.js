import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {F,D,tr,te,mu,sg,w,A,CAUSE,sgn}=await (await fetch('/api/q02/model')).json();

function run(){
 const th=+$('th').value/100,sr=+$('sr').value/100,cc=+$('cc').value;$('tv').textContent=Math.round(th*100)+'% risk';$('sv').textContent=Math.round(sr*100)+'%';
 const ar=D.filter(d=>d.p>=th).sort((a,b)=>b.p-a.p);
 ar.forEach(d=>{let b=0,bj=0;d.c.forEach((v,j)=>{if(v>b){b=v;bj=j}});d.s=bj});
 const exp=ar.reduce((s,d)=>s+d.p*d.mrr*12,0)/1000,save=ar.reduce((s,d)=>s+d.p*d.mrr*12*sr,0)/1000,cost=ar.length*cc/1000;
 $('kpi').innerHTML=kp([['Customers at risk',ar.length+' of '+D.length],['Annual revenue at risk','$'+exp.toFixed(1)+'k'],['Revenue saved at this success rate','$'+save.toFixed(1)+'k'],['Net of contact cost','$'+(save-cost).toFixed(1)+'k',save-cost>0?'pos':'neg']]);
 const ws=w.slice(0,5),mx=Math.max(...ws.map(Math.abs));
 $('drv').innerHTML=F.map((f,j)=>[f,ws[j]]).sort((a,b)=>Math.abs(b[1])-Math.abs(a[1])).map(a=>row(a[0],a[1],mx,(a[1]>0?'+':'')+a[1].toFixed(2),a[1]>0?'n':'b')).join('');
 $('acc').textContent='Red raises churn risk, teal lowers it. Logistic model trained on 630 customers; accuracy on 270 unseen customers (AUC): '+A.toFixed(2)+'.';
 const g=CAUSE.map((c,j)=>({c,j,l:ar.filter(d=>d.s===j)})).filter(x=>x.l.length).sort((a,b)=>b.l.length-a.l.length),gm=Math.max(...g.map(x=>x.l.length),1);
 $('segc').innerHTML=g.map(x=>row(x.c[0],x.l.length,gm,x.l.length)).join('')||'No customers above this threshold.';
 $('seg').innerHTML=tb(['Segment','Customers','Avg risk','MRR at risk','Likely cause','Retention strategy'],g.map(x=>[x.c[0],x.l.length,Math.round(mean(x.l.map(d=>d.p))*100)+'%','$'+Math.round(x.l.reduce((s,d)=>s+d.mrr*d.p,0)).toLocaleString(),x.c[1],x.c[2]]));
 $('top').innerHTML=tb(['Customer','Risk','MRR $','Main driver','Recommended action'],ar.slice(0,10).map(d=>[d.id,Math.round(d.p*100)+'%',d.mrr,CAUSE[d.s][0],CAUSE[d.s][2]]))}
['th','sr','cc'].forEach(i=>$(i).oninput=run);run();
/* AI optimizer */
function OPT(a){const sr=+$('sr').value/100,cc=+$('cc').value;let b=null;for(let t=20;t<=80;t+=5){const ar=D.filter(d=>d.p>=t/100),net=(ar.reduce((s,d)=>s+d.p*d.mrr*12*sr,0)-ar.length*cc)/1000;if(!b||net>b.net)b={t,net,n:ar.length}}
$('optout').innerHTML='Contact customers with risk above <b>'+b.t+'%</b> ('+b.n+' customers). Expected net value: <b>$'+b.net.toFixed(1)+'k</b>. Lower thresholds spend contact cost on customers who would have stayed.';
if(a){$('th').value=b.t;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
