# Q14. What-If Business Simulator (Zepto)
**Problem:** Can pickers, stock, stores and riders cope with 20% more sales?
**Algorithm: Monte-Carlo simulation + hill climbing**
1. 2,000 simulated months. Demand = `10,000 × (1+growth) × (1 + 0.1 z0)`.
2. Capacities: pickers `12,000(1+a0)(1+0.03 z1)`; inventory `(3,000+9,000+900 z2)(1+a1)`; dark-store throughput `12,500(1+a2)(0.95+0.04 z3)`; riders `13,000(1+a3)(0.97+0.03 z4)` (a = capacity added).
3. Fulfilled = `min(demand, smallest capacity)`; the smallest capacity is the binding resource that month.
4. Report average fulfilment, share of months with demand fully met, how often each resource binds, and a growth ladder at 0-40%.
5. **Optimizer:** hill climbing: repeatedly add +10% to one or two resources if net monthly profit `(fulfilled gain × margin) - capacity cost` improves; each resource capped at 40%; at most 20 rounds.

**Code:** `backend/problems/q14.js`. Endpoints: `POST /api/q14/analyze`, `POST /api/q14/optimize`.

---

## Known quirks in the source dashboards (kept as written)
- Q5: the engagement-programme cost per point is 0.3 × headcount in the live calculation but 1.2 × headcount in the optimizer's grid search, so the optimizer is stricter than the sliders.
- Q13: the optimizer's profit function is a closed-form copy of the quarterly model with constants baked in; change both if you change one.


**AI component:** Monte-Carlo simulation + hill-climbing capacity optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q14.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q14-what-if-business-simulator-zepto-standalone.html` also opens directly in a browser with no server.
