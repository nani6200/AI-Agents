import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
const post=(u,b)=>fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}).then(r=>r.json());
const {RS,CPP,NS}=await (await fetch('/api/q14/model')).json();
async function run(){const g=+$('gr').value/100,add=[1,2,3,4].map(i=>+$('c'+i).value/100),mg=+$('mg').value;$('gv').textContent='+'+Math.round(g*100)+'%';[1,2,3,4].forEach(i=>$('v'+i).textContent='+'+Math.round(add[i-1]*100)+'%');
 const {s,b,cmp,safe}=await post('/api/q14/analyze',{g,add}),cost=add.reduce((a,v,i)=>a+v*100*CPP[i],0),gain=(s.ful-b.ful)*mg/1000,bt=s.bd.indexOf(Math.max(...s.bd));
 $('kpi').innerHTML=kp([['Average monthly demand',Math.round(s.dem).toLocaleString()+' units'],['Average fulfilled',Math.round(s.avg*100)+'%',s.avg>.97?'pos':'neg'],['Months demand fully met',Math.round(s.p*100)+'%',s.p>.8?'pos':'neg'],['Extra profit vs today','$'+gain.toFixed(0)+'k / month'],['Capacity cost','$'+cost.toFixed(1)+'k / month'],['Net','$'+(gain-cost).toFixed(0)+'k / month',gain>cost?'pos':'neg']]);
 const tot=NS-s.p*NS||1;$('bd').innerHTML=RS.map((n,i)=>row(n,s.bd[i],Math.max(...s.bd,1),Math.round(s.bd[i]/NS*100)+'% of months',i==bt&&s.bd[bt]>0?'n':'b')).join('')+'<p class="note">Remaining months, demand was fully met.</p>';
 const bins=Array(10).fill(0);s.fr.forEach(v=>bins[Math.min(9,Math.floor(v*10))]++);$('hs').innerHTML=bins.map((c,i)=>row(i*10+'-'+(i+1)*10+'%',c,Math.max(...bins),Math.round(c/NS*100)+'%',i<7?'n':'b')).join('');
 $('cmp').innerHTML=tb(['Growth target','Demand (units)','Fulfilled','Months fully met','Main limit'],[0,10,20,30,40].map((x,xi)=>{const q=cmp[xi],m=q.bd.indexOf(Math.max(...q.bd));return['+'+x+'%',Math.round(q.dem).toLocaleString(),Math.round(q.avg*100)+'%',Math.round(q.p*100)+'%',q.bd[m]?RS[m]:'none']}));
 
 $('rc').innerHTML=ul([s.bd[bt]?'<b>'+RS[bt]+'</b> limits sales most at +'+Math.round(g*100)+'%. Add capacity there first, then re-run; the next limit will appear.':'At +'+Math.round(g*100)+'% every resource keeps up.',safe.length?'With these settings the business can support growth up to about <b>+'+Math.max(...safe)+'%</b> with at least 97% of demand fulfilled.':'Even +0% falls below 97% fulfilled with these settings.','Test one resource at a time: adding capacity to a non-limiting resource raises cost without raising sales.','Phase the growth so capacity and demand rise together.'])}
['gr','c1','c2','c3','c4','mg'].forEach(i=>$(i).oninput=run);run();
/* AI optimizer */
async function OPT(a){const g=+$('gr').value/100,mg=+$('mg').value;const {add:P,net:cur}=await post('/api/q14/optimize',{g,mg});
$('optout').innerHTML='Best additions at +'+Math.round(g*100)+'% growth: '+RS.map((n,i)=>'<b>'+n+'</b> +'+P[i]+'%').join(', ')+'. Net about <b>$'+cur.toFixed(0)+'k a month</b>.';if(a){P.forEach((v,i)=>$('c'+(i+1)).value=v);run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
