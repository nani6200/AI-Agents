// Q14: What-If Business Simulator - Monte-Carlo capacity simulation + hill-climbing capacity planner
import {R,N} from '../lib/stats.js';
export const RS=['Picker hours','Inventory supply','Dark-store throughput','Delivery riders'],CPP=[.6,.4,1,.5],NS=2000;
const r0=R(99),Z=Array.from({length:NS},()=>[N(r0),N(r0),N(r0),N(r0),N(r0)]);
function sim(g,add){let ful=0,full=0,bd=[0,0,0,0],lost=0,dem=0;const fr=[];
 Z.forEach(z=>{const d=10000*(1+g)*(1+.1*z[0]),c=[12000*(1+add[0])*(1+.03*z[1]),(3000+9000+900*z[2])*(1+add[1]),12500*(1+add[2])*(.95+.04*z[3]),13000*(1+add[3])*(.97+.03*z[4])],m=Math.min(...c),f=Math.min(d,m);
  ful+=f;dem+=d;if(f>=d-.5)full++;else bd[c.indexOf(m)]++;fr.push(f/d)});
 return{ful:ful/NS,dem:dem/NS,p:full/NS,bd,fr,avg:ful/dem}}
const GROWTH=[0,10,20,30,40];
// full analysis for one scenario: the scenario, the zero-growth baseline, and a growth ladder
export function analyze(g,add){
 const cmp=GROWTH.map(x=>sim(x/100,add));
 return{s:sim(g,add),b:sim(0,[0,0,0,0]),cmp,safe:GROWTH.filter((x,i)=>cmp[i].avg>.97)}}
// hill-climb: repeatedly add +10% capacity to one or two resources while net monthly profit improves
export function optimize(g,mg){
 let add=[0,0,0,0];const base=sim(0,[0,0,0,0]).ful,net=ad=>(sim(g,ad).ful-base)*mg/1000-ad.reduce((t,v,i)=>t+v*100*CPP[i],0);
 let cur=net(add),mv=true,it=0;
 while(mv&&it++<20){mv=false;let bt=null,bv=cur;for(let i=0;i<4;i++)for(let j=i;j<4;j++){const t=[...add];if(t[i]>.39||t[j]>.39)continue;t[i]+=.1;if(j!=i)t[j]+=.1;const v=net(t);if(v>bv){bv=v;bt=t}}if(bt){add=bt.map(v=>Math.round(v*10)/10);cur=bv;mv=true}}
 return{add:add.map(v=>Math.round(v*100)),net:cur}}
export const buildModel=()=>({RS,CPP,NS});
