# Q5. Employee Attrition Root-Cause (Infosys)
**Problem:** Exits are costly; which factors move attrition and what is the net payoff of an intervention?
**Data:** 1,200 employees in 6 departments; features: overtime, engagement, pay vs market, training hours, absence days, tenure.
**Algorithm: logistic regression + intervention simulation**
1. 840 train / 360 test, standardize, fit logistic regression, report AUC. Baseline attrition = mean predicted probability.
2. Department diagnosis: mean contribution `weight × z` per feature within each department; the largest positive one is that department's main driver.
3. Intervention: change features (overtime down, engagement up by points capped at 10, pay up, training up), re-score everyone, `saved exits = (baseline - new) × headcount`.
4. Net = saved exits × cost per exit - programme cost (pay %, training hours, overtime hours, engagement points each have a unit cost in the code).
5. **Optimizer:** grid search over overtime cut {0,3,6,10}, pay {0,3,6,10,15}, training {0,10,20,30}, engagement {0,5,10,20} on a 300-employee sample; keep the best net.

**Code:** model in `backend/problems/q05.js`; simulation and grid search in `frontend/q05-*/app.js`.


**AI component:** Logistic regression + intervention grid-search optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q05.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q05-employee-attrition-root-cause-infosys-standalone.html` also opens directly in a browser with no server.
