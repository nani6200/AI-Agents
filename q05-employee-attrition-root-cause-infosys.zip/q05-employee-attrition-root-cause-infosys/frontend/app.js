import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {F,DP,ACT,E,tr,te,mu,sg,w,A,base}=await (await fetch('/api/q05/model')).json();
const Z=x=>x.map((v,j)=>(v-mu[j])/sg[j]);

function run(){const ov=+$('ov').value,pv=+$('pv').value,tv=+$('tv').value,ev=+$('ev').value/10,xc=+$('xc').value;
 $('o1').textContent=ov+' hrs';$('o2').textContent=pv+'%';$('o3').textContent=tv+' hrs';$('o4').textContent='+'+ev.toFixed(1);
 const mx=Math.max(...w.slice(0,6).map(Math.abs));$('drv').innerHTML=F.map((f,j)=>[f,w[j]]).sort((a,b)=>Math.abs(b[1])-Math.abs(a[1])).map(a=>row(a[0],a[1],mx,(a[1]>0?'+':'')+a[1].toFixed(2),a[1]>0?'n':'b')).join('');
 $('acc').textContent='Red raises attrition, teal lowers it. Accuracy on unseen employees (AUC): '+A.toFixed(2)+'.';
 const dep=DP.map((n,d)=>{const m=E.filter(e=>e.d==d),c=F.map((_,j)=>mean(m.map(e=>w[j]*Z(e.x)[j])));let b=0,bj=0;c.forEach((v,j)=>{if(v>b){b=v;bj=j}});return{n,a:mean(m.map(e=>e.y))*100,j:bj,c:m.length}});
 $('dep').innerHTML=dep.map(d=>row(d.n,d.a,30,d.a.toFixed(1)+'%',d.a>mean(dep.map(x=>x.a))?'n':'b')).join('');
 const sc=E.map(e=>pred(w,Z([Math.max(0,e.x[0]-ov),Math.min(10,e.x[1]+ev),e.x[2]+pv,e.x[3]+tv,e.x[4],e.x[5]])));
 const nw=mean(sc),saved=(base-nw)*E.length,cost=pv/100*E.length*60+tv*E.length*.02+ov*E.length*.08+ev*E.length*.3;
 const sv=saved*xc,cs=cost,net=sv-cs;$('res').innerHTML=kp([['Attrition now',(base*100).toFixed(1)+'%'],['Attrition after',(nw*100).toFixed(1)+'%'],['Exits avoided / yr',Math.round(saved)],['Saving',k(sv)],['Program cost',k(cs)],['Net',k(net),net>0?'pos':'neg']]);
 $('kpi').innerHTML=kp([['Employees',E.length.toLocaleString()],['Attrition rate',(base*100).toFixed(1)+'%'],['Highest department',dep.slice().sort((a,b)=>b.a-a.a)[0].n],['Top driver',F.map((f,j)=>[f,Math.abs(w[j])]).sort((a,b)=>b[1]-a[1])[0][0]]]);
 $('act').innerHTML=tb(['Department','Attrition','Top driver','Recommended intervention'],dep.map(d=>[d.n,d.a.toFixed(1)+'%',F[d.j],ACT[d.j]]))}
['ov','pv','tv','ev','xc'].forEach(i=>$(i).oninput=run);run();
/* AI optimizer */
function OPT(a){const xc=+$('xc').value,S=E.slice(0,300),b0=mean(S.map(e=>pred(w,Z(e.x))));let b=null;
for(const ov of [0,3,6,10])for(const pv of [0,3,6,10,15])for(const tv of [0,10,20,30])for(const ev of [0,5,10,20]){const sc=S.map(e=>pred(w,Z([Math.max(0,e.x[0]-ov),Math.min(10,e.x[1]+ev/10),e.x[2]+pv,e.x[3]+tv,e.x[4],e.x[5]])));
 const saved=(b0-mean(sc))*E.length,cost=pv/100*E.length*60+tv*E.length*.02+ov*E.length*.08+ev/10*E.length*1.2,net=saved*xc-cost;if(!b||net>b.net)b={ov,pv,tv,ev,net}}
$('optout').innerHTML='Best mix: cut overtime <b>'+b.ov+' hrs</b>, raise pay <b>'+b.pv+'%</b>, add <b>'+b.tv+' training hrs</b>, engagement program <b>+'+(b.ev/10).toFixed(1)+'</b>. Net saving about <b>'+k(b.net)+'</b>.';
if(a){$('ov').value=b.ov;$('pv').value=b.pv;$('tv').value=b.tv;$('ev').value=b.ev;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
