// Q5: Employee Attrition Root-Cause Intelligence - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const r=R(8),F=['Overtime hrs/week','Engagement (1-10)','Pay vs market (%)','Training hrs/yr','Absence days','Tenure (years)'],DP=['Sales','Engineering','Support','Finance','Operations','Marketing'],ACT={0:'Rebalance workload and cap overtime.',1:'Run stay interviews and fix manager issues.',2:'Review pay bands against market.',3:'Fund training and career paths.',4:'Check wellbeing and scheduling.',5:'Build early-career mentoring.'};
const E=[];for(let i=0;i<1200;i++){const d=Math.floor(r()*6),ot=Math.max(0,4+d*1.6*(d==0||d==2?1:.5)+N(r)*4),en=Math.min(10,Math.max(1,6.5-ot*.12+N(r)*1.5)),pay=100+N(r)*8,tr=Math.max(0,20+N(r)*12),ab=Math.max(0,3+N(r)*2+ot*.15),te=Math.max(.3,4+N(r)*3);
 const z=-.9+.1*ot-.35*en-.05*(pay-100)-.012*tr+.18*ab-.1*te+N(r)*.4;E.push({d,x:[ot,en,pay-100,tr,ab,te],y:r()<sig(z)?1:0})}
const tr=E.slice(0,840),te=E.slice(840),mu=F.map((_,j)=>mean(tr.map(e=>e.x[j]))),sg=F.map((_,j)=>sd(tr.map(e=>e.x[j])));
const Z=x=>x.map((v,j)=>(v-mu[j])/sg[j]),w=logit(tr.map(e=>Z(e.x)),tr.map(e=>e.y));
const A=auc(te.map(e=>pred(w,Z(e.x))),te.map(e=>e.y)),base=mean(E.map(e=>pred(w,Z(e.x))));
return {F,DP,ACT,E,tr,te,mu,sg,w,A,base};
}
