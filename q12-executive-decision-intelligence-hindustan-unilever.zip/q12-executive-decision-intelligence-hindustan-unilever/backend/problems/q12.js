// Q12: Executive Decision Intelligence - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const NM=['Trade discount depth %','Stock-outs','OTIF delivery %','Distribution reach %','Consumer complaints','Ad spend index','Market share %','Working capital days','Returns %','Headcount','Social mentions','Overtime hours'],T=104,r=R(52);
const X=NM.map(()=>{const a=[];let v=N(r);for(let t=0;t<T;t++){v=.6*v+N(r)*.8;a.push(v)}return a});
const M=[];for(let t=0;t<T;t++){const g=(j,l)=>X[j][Math.max(0,t-l)];M.push(20-1.5*g(0,0)-1.1*g(1,1)+1.0*g(2,2)+.8*g(3,1)-.4*g(4,2)+N(r)*.9)}
const BL=NM.map((_,j)=>{let b=0,bl=0,bc=0;for(let l=0;l<=4;l++){const c=corr(X[j].slice(0,T-l),M.slice(l));if(Math.abs(c)>Math.abs(bc)){bc=c;bl=l}}return{j,l:bl,c:bc}}).sort((a,b)=>Math.abs(b.c)-Math.abs(a.c));
const feat=(B,t)=>B.map(b=>X[b.j][t-b.l]);
function fit(n){const B=BL.slice(0,n),rows=[],ys=[];for(let t=4;t<T;t++){rows.push(feat(B,t));ys.push(M[t])}const mu=B.map((_,i)=>mean(rows.map(r=>r[i]))),sg=B.map((_,i)=>sd(rows.map(r=>r[i])));return{B,mu,sg,...ols(rows.map(r=>r.map((v,i)=>(v-mu[i])/sg[i])),ys)}}
const R2=[1,2,3,4,5,6,7,8].map(n=>fit(n).r2);
const FITS=[1,2,3,4,5,6,7,8].map(fit);
return {NM,T,X,M,BL,R2,FITS};
}
