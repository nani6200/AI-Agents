// Zero-dependency Node server: serves the frontend and exposes the algorithm API.
//   GET  /api/problems            -> list of the 14 problems
//   GET  /api/qNN/model           -> dataset + fitted model for problem NN (cached)
//   POST /api/q01/optimize        -> budget allocation        POST /api/q01/best-budget
//   POST /api/q14/analyze         -> Monte-Carlo scenario      POST /api/q14/optimize
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const FRONT = path.join(here, '..', 'frontend');
const PORT = process.env.PORT || 3000;
const MIME = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json', '.svg':'image/svg+xml', '.png':'image/png', '.ico':'image/x-icon' };

// load every problem module once
const problems = {};
for (const f of fs.readdirSync(path.join(here, 'problems')).filter(f => /^q\d\d\.js$/.test(f)).sort()) {
  problems[f.slice(0, 3)] = await import('./problems/' + f);
}
const cache = {};
const model = id => cache[id] ??= problems[id].buildModel();
const slugs = fs.readdirSync(FRONT).filter(d => /^q\d\d-/.test(d)).sort();

const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, no) => { let b = ''; req.on('data', c => { b += c; if (b.length > 5e6) req.destroy(); }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { no(e); } }); });

async function api(req, res, url) {
  const parts = url.pathname.split('/').filter(Boolean); // ['api', 'q01', 'optimize']
  if (parts[1] === 'problems') return json(res, 200, slugs.map(s => ({ id: s.slice(0, 3), slug: s, url: '/' + s + '/', api: '/api/' + s.slice(0, 3) + '/model' })));
  const id = parts[1], P = problems[id];
  if (!P) return json(res, 404, { error: 'unknown problem' });
  if (req.method === 'GET' && parts[2] === 'model') return json(res, 200, model(id));
  if (req.method === 'POST') {
    const b = await body(req);
    if (id === 'q01' && parts[2] === 'optimize') return json(res, 200, P.optimize(b.C, b.T, b.cut, b.up));
    if (id === 'q01' && parts[2] === 'best-budget') return json(res, 200, P.bestBudget(b.C, b.cut, b.up));
    if (id === 'q14' && parts[2] === 'analyze') return json(res, 200, P.analyze(b.g, b.add));
    if (id === 'q14' && parts[2] === 'optimize') return json(res, 200, P.optimize(b.g, b.mg));
  }
  return json(res, 404, { error: 'unknown endpoint' });
}

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    let p = path.normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[/\\])+/, '');
    let f = path.join(FRONT, p);
    if (!f.startsWith(FRONT)) { res.writeHead(403); return res.end(); }
    if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, 'index.html');
    if (!fs.existsSync(f)) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
    fs.createReadStream(f).pipe(res);
  } catch (e) { json(res, 500, { error: String(e.message || e) }); }
}).listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
