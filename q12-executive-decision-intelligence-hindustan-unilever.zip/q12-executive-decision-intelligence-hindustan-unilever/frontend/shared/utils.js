// Shared UI + math helpers used by every problem's app.js (ES module)
const $=id=>document.getElementById(id),k=v=>'$'+Math.round(v).toLocaleString()+'k';
const R=s=>()=>(s=s*16807%2147483647)/2147483647;
const N=r=>(r()+r()+r()+r()+r()+r()-3)*1.414;
const sig=z=>1/(1+Math.exp(-z)),mean=a=>a.reduce((x,y)=>x+y,0)/(a.length||1);
const sd=a=>{const m=mean(a);return Math.sqrt(mean(a.map(v=>(v-m)**2)))||1};
const fm=v=>Math.abs(v)>=100?Math.round(v).toLocaleString():(+v).toFixed(1);
function logit(X,y,it=250,lr=.4){const n=X.length,p=X[0].length;let w=Array(p+1).fill(0);for(let t=0;t<it;t++){const g=Array(p+1).fill(0);for(let i=0;i<n;i++){let z=w[p];for(let j=0;j<p;j++)z+=w[j]*X[i][j];const e=sig(z)-y[i];for(let j=0;j<p;j++)g[j]+=e*X[i][j];g[p]+=e}for(let j=0;j<=p;j++)w[j]-=lr*g[j]/n}return w}
const pred=(w,x)=>{let z=w[w.length-1];for(let j=0;j<x.length;j++)z+=w[j]*x[j];return sig(z)};
function auc(s,y){const P=[],Q=[];s.forEach((v,i)=>(y[i]?P:Q).push(v));let c=0;P.forEach(a=>Q.forEach(b=>c+=a>b?1:a==b?.5:0));return c/(P.length*Q.length||1)}
function solve(A,b){const n=b.length,M=A.map((r,i)=>[...r,b[i]]);for(let i=0;i<n;i++){let m=i;for(let r=i+1;r<n;r++)if(Math.abs(M[r][i])>Math.abs(M[m][i]))m=r;[M[i],M[m]]=[M[m],M[i]];for(let r=0;r<n;r++)if(r!=i){const f=M[r][i]/(M[i][i]||1e-9);for(let c=i;c<=n;c++)M[r][c]-=f*M[i][c]}}return M.map((r,i)=>r[n]/(r[i]||1e-9))}
function ols(X,y){const n=X.length,p=X[0].length+1,Z=X.map(r=>[1,...r]);const A=Array.from({length:p},(_,i)=>Array.from({length:p},(_,j)=>Z.reduce((s,r)=>s+r[i]*r[j],0)+(i==j&&i>0?1e-6:0)));const b=Array.from({length:p},(_,i)=>Z.reduce((s,r,t)=>s+r[i]*y[t],0));const w=solve(A,b),my=mean(y);let sse=0,sst=0;Z.forEach((r,t)=>{const e=y[t]-r.reduce((s,v,j)=>s+v*w[j],0);sse+=e*e;sst+=(y[t]-my)**2});return{w,r2:1-sse/sst}}
const corr=(a,b)=>{const ma=mean(a),mb=mean(b);let s=0,x=0,y=0;a.forEach((v,i)=>{s+=(v-ma)*(b[i]-mb);x+=(v-ma)**2;y+=(b[i]-mb)**2});return s/Math.sqrt(x*y||1)};
const row=(l,v,mx,txt,c)=>'<div class="row"><span>'+l+'</span><div class="t"><div class="f '+(c||'b')+'" style="width:'+Math.max(1,Math.abs(v)/(mx||1)*100)+'%"></div></div><span class="v">'+txt+'</span></div>';
const kp=a=>a.map(x=>'<div><span>'+x[0]+'</span><strong class="'+(x[2]||'')+'">'+x[1]+'</strong></div>').join('');
const tb=(h,r)=>'<table><tr>'+h.map(x=>'<th>'+x+'</th>').join('')+'</tr>'+r.map(a=>'<tr>'+a.map(x=>'<td>'+x+'</td>').join('')+'</tr>').join('')+'</table>';
const ul=a=>a.map(t=>'<li>'+t+'</li>').join('');
function lc(S,o={}){const W=640,H=o.h||220,p=36,L=o.L||[],all=S.flatMap(s=>s.d);const lo=o.min??Math.min(...all,...L.map(l=>l.y)),hi=o.max??Math.max(...all,...L.map(l=>l.y));const n=Math.max(...S.map(s=>(s.o||0)+s.d.length))-1;const X=i=>p+i/n*(W-p-8),Y=v=>H-24-(v-lo)/((hi-lo)||1)*(H-40);
let g='<svg viewBox="0 0 '+W+' '+H+'" width="100%" role="img"><text x="2" y="'+(Y(hi)+4)+'" font-size="11" fill="var(--mu)">'+fm(hi)+'</text><text x="2" y="'+(Y(lo)+4)+'" font-size="11" fill="var(--mu)">'+fm(lo)+'</text><line x1="'+p+'" x2="'+(W-8)+'" y1="'+(H-24)+'" y2="'+(H-24)+'" stroke="var(--ln)"/>';
L.forEach(l=>g+='<line x1="'+p+'" x2="'+(W-8)+'" y1="'+Y(l.y)+'" y2="'+Y(l.y)+'" stroke="'+(l.c||'var(--dn)')+'" stroke-dasharray="4 3"/><text x="'+(W-10)+'" y="'+(Y(l.y)-4)+'" text-anchor="end" font-size="11" fill="'+(l.c||'var(--dn)')+'">'+l.t+'</text>');
S.forEach(s=>g+='<polyline fill="none" stroke="'+s.c+'" stroke-width="'+(s.w||2)+'" '+(s.dash?'stroke-dasharray="5 4" ':'')+'points="'+s.d.map((v,i)=>X((s.o||0)+i)+','+Y(v)).join(' ')+'"/>');
return g+'</svg>'}

export {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc};
