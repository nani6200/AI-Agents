import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {NM,T,X,M,BL,R2,FITS}=await (await fetch('/api/q12/model')).json();
const fit=n=>FITS[n-1];
const feat=(B,t)=>B.map(b=>X[b.j][t-b.l]);
function run(){const n=+$('nk').value;$('nv').textContent=n;const F=fit(n),sg=F.sg;
 const t=T-1,dm=M[t]-M[t-1],ct=F.B.map((b,i)=>({n:NM[b.j],c:F.w[i+1]*((X[b.j][t-b.l]-X[b.j][t-1-b.l])/sg[i])})).sort((a,b)=>Math.abs(b.c)-Math.abs(a.c));
 const rest=dm-ct.reduce((a,x)=>a+x.c,0);
 $('nar').innerHTML='<p>Margin <b>'+(dm<0?'fell ':'rose ')+Math.abs(dm).toFixed(2)+' points</b> to '+M[t].toFixed(1)+'%. '+ct.slice(0,3).map(x=>'<b>'+x.n+'</b> contributed '+(x.c>=0?'+':'')+x.c.toFixed(2)).join('; ')+'. Other factors and noise account for '+(rest>=0?'+':'')+rest.toFixed(2)+'.</p><p class="note">Contributions come from a regression on the '+n+' tracked KPIs, using each KPI\u2019s best delay.</p>';
 const top=BL.slice(0,n).map(b=>b.j),mx=Math.abs(BL[0].c);
 $('rk').innerHTML=BL.map(b=>row(NM[b.j],b.c,mx,(b.c>0?'+':'')+b.c.toFixed(2)+', '+b.l+'w',top.includes(b.j)?(b.c<0?'n':'b'):'g')).join('');
 $('r2').innerHTML=R2.map((v,i)=>row(i+1+' KPI'+(i?'s':''),v,1,Math.round(v*100)+'%',i+1==n?'b':'g')).join('');
 $('kpi').innerHTML=kp([['KPIs tracked',n+' of '+NM.length],['Margin explained',Math.round(R2[n-1]*100)+'%','pos'],['Extra margin explained by tracking all 8','+'+Math.round((R2[7]-R2[n-1])*100)+' pts']]);
 $('tbl').innerHTML=tb(['KPI','Best delay','Relationship','Margin explained alone','Verdict'],BL.map((b,i)=>[NM[b.j],b.l?b.l+' weeks':'same week',(b.c>0?'+':'')+b.c.toFixed(2),Math.round(b.c*b.c*100)+'%','<span class="chip '+(Math.abs(b.c)>.3?'Scale':'Hold')+'">'+(Math.abs(b.c)>.3?'Keep':'Retire or demote')+'</span>']))}
$('nk').oninput=run;run();
/* AI optimizer */
function OPT(a){let n=8;for(let i=1;i<8;i++)if(R2[i]-R2[i-1]<.02){n=i;break}
$('optout').innerHTML='Track <b>'+n+' KPIs</b> ('+Math.round(R2[n-1]*100)+'% of margin explained). Adding another KPI gains under 2 points.';if(a){$('nk').value=n;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
