# Q12. Executive Decision Intelligence (Hindustan Unilever)
**Problem:** Many KPIs; which explain margin?
**Data:** 12 KPI time series × 104 weeks (autocorrelated); margin driven by five of them at different lags.
**Algorithm: lagged correlation + regression**
1. For each KPI compute the correlation with margin at lags 0-4 weeks; keep the lag with the largest absolute correlation. Rank KPIs.
2. `fit(n)`: OLS of margin on the top-n KPIs (each at its best lag, standardized). R² computed for n = 1..8.
3. Narrative: week-over-week margin change split into each KPI's contribution (`coefficient × standardized change at its lag`) plus an unexplained rest.
4. **Optimizer:** smallest n where adding one more KPI raises R² by less than 0.02.

**Code:** `backend/problems/q12.js` (lags, `fit`, R² table cached); narrative in `app.js`.


**AI component:** Lagged-correlation + regression KPI selector

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q12.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q12-executive-decision-intelligence-hindustan-unilever-standalone.html` also opens directly in a browser with no server.
