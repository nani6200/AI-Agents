import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {SK,MO,EM,s0,L1,PR,dem}=await (await fetch('/api/q06/model')).json();
const col=g=>g>.5?'rgba(192,57,43,'+Math.min(.85,.2+g/3)+')':'rgba(27,107,102,.15)';
const hm=(G)=>'<table class="hm"><tr><th>Skill</th>'+Array.from({length:MO},(_,m)=>'<th>M'+(m+1)+'</th>').join('')+'</tr>'+SK.map((s,i)=>'<tr><td>'+s+'</td>'+G[i].map(g=>'<td style="background:'+col(g)+'">'+(g>.5?'+'+g.toFixed(1):'ok')+'</td>').join('')+'</tr>').join('')+'</table>';
function run(){const ts=+$('ts').value,hl=+$('hl').value,ct=+$('ct').value,ch=+$('ch').value;$('s1').textContent=ts;$('s2').textContent=hl+' months';
 const G0=dem.map((d,s)=>d.map(v=>v-s0[s])),P=SK.map((n,s)=>{const g=Math.max(...G0[s]);if(g<=.5)return{n,t:0,h:0,g};const t=Math.min(ts,L1[s],Math.ceil(g*2)),rem=g-.5*t;return{n,t,h:rem>.25?Math.ceil(rem):0,g}});
 const G1=dem.map((d,s)=>d.map((v,m)=>v-(s0[s]+(m>=2?.5*P[s].t:0)+(m>=hl?P[s].h:0))));
 const c0=G0.flat().filter(g=>g>.5).length,c1=G1.flat().filter(g=>g>.5).length,cost=P.reduce((a,p)=>a+p.t*ct+p.h*ch,0);
 $('kpi').innerHTML=kp([['Skill-months short today',c0,'neg'],['Short after plan',c1,c1<c0?'pos':'neg'],['People to train',P.reduce((a,p)=>a+p.t,0)],['People to hire',P.reduce((a,p)=>a+p.h,0)],['Plan cost',k(cost)]]);
 $('h0').innerHTML=hm(G0);$('h1').innerHTML=hm(G1);
 $('pl').innerHTML=tb(['Skill','Peak gap (people)','Train','Hire','Why'],P.filter(p=>p.g>.5).sort((a,b)=>b.g-a.g).map(p=>[p.n,p.g.toFixed(1),p.t,p.h,p.t?'Train from '+L1[SK.indexOf(p.n)]+' staff with basic skill (cheaper, ready in 2 months); hire for the rest.':'No in-house learners; hire or contract.']))}
['ts','hl','ct','ch'].forEach(i=>$(i).oninput=run);run();
/* AI optimizer */
function calc(ts,hl,ct,ch){const G0=dem.map((d,s)=>d.map(v=>v-s0[s])),P=SK.map((n,s)=>{const g=Math.max(...G0[s]);if(g<=.5)return{t:0,h:0};const t=Math.min(ts,L1[s],Math.ceil(g*2)),rem=g-.5*t;return{t,h:rem>.25?Math.ceil(rem):0}});
 const G1=dem.map((d,s)=>d.map((v,m)=>v-(s0[s]+(m>=2?.5*P[s].t:0)+(m>=hl?P[s].h:0))));return{c1:G1.flat().filter(g=>g>.5).length,cost:P.reduce((a,p)=>a+p.t*ct+p.h*ch,0)}}
function OPT(a){const hl=+$('hl').value,ct=+$('ct').value,ch=+$('ch').value;let b=null;for(let ts=0;ts<=4;ts++){const r=calc(ts,hl,ct,ch),tot=r.cost+r.c1*10;if(!b||tot<b.tot)b={ts,tot,...r}}
$('optout').innerHTML='Best: <b>'+b.ts+' training seats per skill</b>. Plan cost '+k(b.cost)+' with '+b.c1+' skill-months still short (each counted as a $10k delay cost).';if(a){$('ts').value=b.ts;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
