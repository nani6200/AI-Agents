// Q6: Workforce Capacity and Skill Gap - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const SK=['Cloud','Data eng.','ML','Security','UX','Project mgmt','QA','Backend'],MO=8,r=R(14);
const EM=[];for(let i=0;i<26;i++){const lv=SK.map(()=>r()<.3?1:0);const p=Math.floor(r()*8);lv[p]=3;if(r()<.4)lv[(p+1+Math.floor(r()*7))%8]=2;EM.push(lv)}
const s0=SK.map((_,s)=>EM.reduce((a,l)=>{const q=l.filter(v=>v>=2).length;return a+(l[s]>=2?1/q:0)},0)),L1=SK.map((_,s)=>EM.filter(l=>l[s]==1).length);
const PR=[[1,4,{Cloud:2.5,Backend:2}],[2,6,{ML:2.5,'Data eng.':2}],[3,8,{Security:2,Cloud:1.5}],[1,3,{UX:1.5,QA:1}],[4,8,{ML:1.5,Backend:2,QA:1.5}],[2,7,{'Project mgmt':1.5,UX:1}],[5,8,{'Data eng.':2,Security:1.5,QA:1}]];
const dem=SK.map(s=>Array.from({length:MO},(_,m)=>PR.reduce((a,p)=>a+(m+1>=p[0]&&m+1<=p[1]?(p[2][s]||0):0),0)));
return {SK,MO,EM,s0,L1,PR,dem};
}
