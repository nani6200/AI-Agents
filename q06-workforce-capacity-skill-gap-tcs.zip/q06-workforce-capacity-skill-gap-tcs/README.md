# Q6. Workforce Capacity and Skill Gap (TCS)
**Problem:** Enough people on paper, wrong skills in the wrong months.
**Data:** 26 employees × 8 skills (3 expert, 2 capable, 1 beginner, 0 none); 7 projects with start/end month and FTE demand per skill.
**Algorithm: supply-demand gap + training/hiring plan**
1. Supply per skill = Σ over employees with level ≥ 2 of `1/(number of skills they are capable in)`, so a two-skill person counts half in each.
2. Demand per skill and month = sum of demands of projects running that month.
3. Gap = demand - supply per skill-month; a gap above 0.5 FTE is "short".
4. Plan per short skill: trainees `t = min(seats, beginners available, ceil(2 × maxGap))`, each trainee counts 0.5 FTE from month 3; remaining gap `rem = maxGap - 0.5t`; hires `h = ceil(rem)` if `rem > 0.25`, arriving at the chosen hiring lead time.
5. Cost = trainees × training cost + hires × hiring cost.
6. **Optimizer:** try 0-4 training seats per skill; minimise plan cost + $10k × skill-months still short.

**Code:** data in `backend/problems/q06.js`; plan and optimizer in `app.js`.


**AI component:** Gap model + training/hiring cost optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q06.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q06-workforce-capacity-skill-gap-tcs-standalone.html` also opens directly in a browser with no server.
