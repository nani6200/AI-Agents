// Q1: Marketing Budget Optimizer - diminishing-returns response curves + greedy marginal-return allocation
export const CHANNELS=[
{n:'Search ads',s:120,r:380,b:.55,c:3200},{n:'Instagram and Meta',s:90,r:210,b:.45,c:1900},
{n:'Push and email',s:25,r:160,b:.8,c:1500},{n:'Display',s:80,r:95,b:.35,c:800},
{n:'Food creators',s:60,r:150,b:.5,c:1100},{n:'Restaurant co-funding',s:40,r:130,b:.7,c:1300},
{n:'YouTube',s:70,r:140,b:.6,c:1000}];
const sum=a=>a.reduce((x,y)=>x+y,0);
// revenue of a channel at spend s:  R0 * (s/S0)^b
export const rev=(c,s)=>c.r*Math.pow(Math.max(s,.01)/c.s,c.b);
// marginal revenue of the next $1k:  d/ds of the curve
export const mr=(c,s)=>c.b*c.r/c.s*Math.pow(Math.max(s,.01)/c.s,c.b-1);
// greedy: start at the lower bounds, add $1k at a time to the channel with the highest marginal return
export function opt(C,T,cut,up){
 const lo=C.map(c=>c.s*(1-cut)),hi=C.map(c=>c.s*(1+up)),x=[...lo];
 let left=T-sum(lo);
 if(left<0){const f=T/sum(lo);return lo.map(v=>v*f)}
 while(left>.5){let j=-1,m=-1;C.forEach((c,i)=>{if(x[i]+1<=hi[i]){const g=mr(c,x[i]+.5);if(g>m){m=g;j=i}}});
  if(j<0)break;x[j]+=1;left-=1}
 return x}
export function optimize(C,T,cut,up){
 const x=opt(C,T,cut,up);
 return{x,rev:C.map((c,i)=>rev(c,x[i])),m0:C.map(c=>mr(c,c.s)),m1:C.map((c,i)=>mr(c,x[i]))}}
// sweep total budget 70%..200% of today and pick the one with best net return (revenue - spend)
export function bestBudget(C,cut,up){
 const T0=sum(C.map(c=>c.s));let b=null;
 for(let p=70;p<=200;p+=5){const T=T0*p/100,x=opt(C,T,cut,up),R=sum(C.map((c,i)=>rev(c,x[i]))),pf=R-T;if(!b||pf>b.pf)b={p,pf,T}}
 return b}
export const buildModel=()=>({channels:CHANNELS});
