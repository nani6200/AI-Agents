const post=(u,b)=>fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}).then(r=>r.json());
const {channels:C}=await (await fetch('/api/q01/model')).json();
const $=id=>document.getElementById(id),k=v=>'$'+Math.round(v).toLocaleString()+'k';
async function run(){
 const T0=C.reduce((a,c)=>a+c.s,0),pct=+$('tb').value,cut=+$('cb').value/100,up=+$('ub').value/100,T=T0*pct/100;
 $('tv').textContent=k(T)+' ('+pct+'%)';$('cv').textContent=Math.round(cut*100)+'%';$('uv').textContent=Math.round(up*100)+'%';
 const OP=await post('/api/q01/optimize',{C,T,cut,up}),x=OP.x,R0=C.reduce((a,c)=>a+c.r,0),R1=OP.rev.reduce((a,b)=>a+b,0);
 const roi0=(R0-T0)/T0,roi1=(R1-T)/T,lift=R1-R0;
 $('kpi').innerHTML=[['Revenue now',k(R0),''],['Revenue recommended',k(R1),''],['Change',(lift>=0?'+':'')+k(lift)+' ('+(lift/R0*100).toFixed(1)+'%)',lift>=0?'pos':'neg'],['Net ROI',(roi0*100).toFixed(0)+'% to '+(roi1*100).toFixed(0)+'%','']].map(a=>'<div><span>'+a[0]+'</span><strong class="'+a[2]+'">'+a[1]+'</strong></div>').join('');
 const mx=Math.max(...C.map((c,i)=>Math.max(c.s,x[i])));
 $('chart').innerHTML=C.map((c,i)=>'<div class="row"><span>'+c.n+'</span><div class="pair"><div class="t"><div class="f a" style="width:'+c.s/mx*100+'%"></div></div><div class="t"><div class="f b" style="width:'+x[i]/mx*100+'%"></div></div></div><span style="text-align:right">'+k(c.s)+' to '+k(x[i])+'</span></div>').join('');
 const rows=C.map((c,i)=>{const d=(x[i]-c.s)/c.s,v=d>.05?'Scale':d<-.05?'Cut':'Hold';return{c,i,d,v,m:OP.m0[i],cac:c.s*1000/c.c,m1:OP.m1[i]}});
 const cuts=rows.filter(r=>r.v==='Cut').sort((a,b)=>a.d-b.d),ups=rows.filter(r=>r.v==='Scale').sort((a,b)=>b.d-a.d);
 const A=[];
 if(cuts.length)A.push('Reduce <b>'+cuts.map(r=>r.c.n+' ('+Math.round(r.d*100)+'%)').join(', ')+'</b>. Each extra dollar there earns the least ('+cuts.map(r=>'$'+r.m.toFixed(2)).join(', ')+' per $1 at today\u2019s spend).');
 if(ups.length)A.push('Increase <b>'+ups.map(r=>r.c.n+' (+'+Math.round(r.d*100)+'%)').join(', ')+'</b>. They still return the most on the next dollar ('+ups.map(r=>'$'+r.m.toFixed(2)).join(', ')+').');
 const bad=rows.filter(r=>r.m<1);
 if(bad.length)A.push('<b>'+bad.map(r=>r.c.n).join(', ')+'</b> return less than $1 per extra $1 spent today. That spend is inefficient even before comparing channels.');
 A.push('After the move, marginal returns land between $'+Math.min(...rows.map(r=>r.m1)).toFixed(2)+' and $'+Math.max(...rows.map(r=>r.m1)).toFixed(2)+' per $1. The closer they are, the less a further shift helps.');
 A.push('Phase the change over 2 to 3 months and keep a holdout region per channel to check the curves are right before the next move.');
 $('acts').innerHTML=A.map(t=>'<li>'+t+'</li>').join('');
 const rc=$('tbl').rows;rows.forEach(r=>{const t=rc[r.i+1];t.cells[4].textContent=r.cac.toFixed(0);t.cells[5].textContent='$'+r.m.toFixed(2);t.cells[6].textContent=k(x[r.i]);t.cells[7].innerHTML='<span class="chip '+r.v+'">'+r.v+'</span>'})}
$('tbl').innerHTML='<tr><th>Channel</th><th>Spend $k</th><th>Revenue $k</th><th>Curve b</th><th>CAC $</th><th>Return on next $1</th><th>Recommended</th><th>Action</th></tr>'+C.map((c,i)=>'<tr><td>'+c.n+'</td><td><input type="number" min="1" data-i="'+i+'" data-f="s" value="'+c.s+'"></td><td><input type="number" min="1" data-i="'+i+'" data-f="r" value="'+c.r+'"></td><td><input type="number" step=".05" min=".1" max="1" data-i="'+i+'" data-f="b" value="'+c.b+'"></td><td></td><td></td><td></td><td></td></tr>').join('');
$('tbl').oninput=e=>{const t=e.target,v=parseFloat(t.value);if(t.dataset.f&&v>0){C[t.dataset.i][t.dataset.f]=v;run()}};
['tb','cb','ub'].forEach(i=>$(i).oninput=run);run();

/* AI optimizer */
async function OPT(a){const cut=+$('cb').value/100,up=+$('ub').value/100;const b=await post('/api/q01/best-budget',{C,cut,up});
$('optout').innerHTML='Best total budget: <b>'+b.p+'% of today ('+k(b.T)+')</b>. Net return after spend peaks at '+k(b.pf)+'; above that, extra budget earns less than it costs.';
if(a){$('tb').value=b.p;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
