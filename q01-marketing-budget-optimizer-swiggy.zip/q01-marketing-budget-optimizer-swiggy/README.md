# Q1. Marketing Budget Optimizer (Swiggy)
**Problem:** Spend is spread over seven channels and nobody knows where an extra rupee pays back.
**Input:** per channel: spend S0, revenue R0, curve exponent b (lower = saturates faster), conversions.
**Algorithm: diminishing-returns curves + greedy marginal allocation**
1. Revenue of a channel at spend s: `R(s) = R0 × (s/S0)^b`.
2. Marginal return of the next $1k: `R'(s) = b × R0/S0 × (s/S0)^(b-1)`.
3. Bounds per channel: `lo = S0×(1-maxCut)`, `hi = S0×(1+maxIncrease)`. Start every channel at `lo`.
4. Money left = total budget - Σlo. (If negative, scale `lo` down proportionally.)
5. Repeat: give $1k to the channel with the highest `R'` that is still below `hi`, until the money is gone.
6. After the move marginal returns across channels are nearly equal, which is the optimum condition for concave curves.
7. **Best total budget:** sweep 70%-200% of today's budget in 5% steps, run steps 3-5, and keep the budget with the highest `revenue - spend`.
8. Labels: Scale if spend rises more than 5%, Cut if it falls more than 5%, else Hold. CAC = spend/conversions.

**Code:** `backend/problems/q01.js` (`opt`, `optimize`, `bestBudget`). Endpoints: `POST /api/q01/optimize`, `POST /api/q01/best-budget`.


**AI component:** Response-curve fitting + greedy marginal-return optimizer ("Apply best settings")

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q01.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q01-marketing-budget-optimizer-swiggy-standalone.html` also opens directly in a browser with no server.
