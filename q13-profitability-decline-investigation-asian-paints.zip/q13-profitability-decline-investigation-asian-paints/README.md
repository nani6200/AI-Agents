# Q13. Profitability Decline Investigation (Asian Paints)
**Problem:** Profit falls while every department hits its target.
**Data:** a 12-quarter model: trade discount rises from Q10; freight, overtime, attrition and receivable days follow.
**Algorithm: profit waterfall + cross-department correlation + discount curve**
1. Profit = revenue - COGS - freight - labour and overtime - hiring after exits - marketing - financing of receivables.
2. Waterfall: change of each line between the chosen quarter and Q12.
3. Pearson correlation between six metrics owned by Marketing, Operations, HR and Finance across the 12 quarters; the strongest cross-department pairs show how one decision lands in another's cost. (Trends can create false links; the order of events supports the chain.)
4. **Optimizer:** evaluate profit as a function of discount 0%-12% with all knock-on costs and pick the maximum.

**Code:** `backend/problems/q13.js` (quarterly model); waterfall and discount curve in `app.js`.


**AI component:** Profit-driver waterfall + discount optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q13.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q13-profitability-decline-investigation-asian-paints-standalone.html` also opens directly in a browser with no server.
