// Q13: Profitability Decline Investigation - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const S=9,Q=[];for(let q=0;q<12;q++){const disc=q<S?5:5+(q-S+1)*1.6,units=10000*(1+.015*q)*(1+(disc-5)*.025),rev=units*100*(1-disc/100),cogs=units*45,fr=units*(5+(q>S?(q-S)*.5:0)),ot=1500+Math.max(0,units-10800)*.5,lab=150000+ot*38,att=3+(q>S?(q-S)*.7:0),rep=220*att/100*5500,mk=90000+(q>=S?(q-S+1)*6000:0),ar=42+(q>=S?(q-S+1)*3.5:0),fin=rev*ar/90*.0275;
 Q.push({q,disc,units,rev,cogs,fr,lab,rep,mk,fin,ot,att,ar,pr:rev-cogs-fr-lab-rep-mk-fin})}
const DR=[['Revenue','rev',1],['Cost of goods','cogs',-1],['Freight','fr',-1],['Labor and overtime','lab',-1],['Hiring after exits','rep',-1],['Marketing spend','mk',-1],['Financing receivables','fin',-1]];
const MT=[['Discount % (Marketing)','disc'],['Units sold (Marketing)','units'],['Freight per unit (Ops)','fu'],['Overtime hours (Ops)','ot'],['Attrition % (HR)','att'],['Receivable days (Finance)','ar']];
Q.forEach(x=>x.fu=x.fr/x.units);
return {S,Q,DR,MT};
}
