// Q10: Inventory Optimization - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const NM=['Basmati rice 5kg','Sunflower oil 1L','Toor dal 1kg','Detergent 2kg','Biscuit family pack','Tea 500g','Toothpaste','Atta 10kg'],r=R(41);
const S=NM.map((n,i)=>{const b=40+r()*160,am=.1+r()*.4,ph=r()*6.28,g=(r()-.4)*.004,d=[];for(let t=0;t<104;t++)d.push(Math.max(1,Math.round(b*(1+g*t)*(1+am*Math.sin(6.283*t/52+ph))+N(r)*b*.1)));
 const cost=5+r()*60,LT=1+Math.floor(r()*6),f=[];const ra=t=>mean(d.slice(t-8,t))/Math.max(1,mean(d.slice(t-60,t-52)));const rt=Math.min(1.4,Math.max(.7,ra(104)));for(let t=0;t<8;t++)f.push(d[104-52+t]*rt);
 const res=[];for(let t=78;t<104;t++){const q=Math.min(1.4,Math.max(.7,mean(d.slice(t-8,t))/Math.max(1,mean(d.slice(t-60,t-52)))));res.push(d[t]-d[t-52]*q)}
 const dem=d.slice(-8).reduce((a,b)=>a+b)/8;return{n,d,f,sg:sd(res),cost,LT,oh:Math.round(dem*(.5+r()*11)),oo:r()<.4?Math.round(dem*LT*.7):0,rev:mean(d.slice(-52))*cost*1.4*52}});
return {NM,S};
}
