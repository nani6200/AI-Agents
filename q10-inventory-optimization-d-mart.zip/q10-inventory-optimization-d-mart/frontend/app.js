import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {NM,S}=await (await fetch('/api/q10/model')).json();
const zf=p=>4.91*(Math.pow(p,.14)-Math.pow(1-p,.14)),sel=$('sk');sel.innerHTML=NM.map((n,i)=>'<option value="'+i+'">'+n+'</option>').join('');
function run(){const i=+sel.value,p=+$('sl').value/100,hc=+$('hc').value/100,z=zf(p);$('sv').textContent=Math.round(p*100)+'%';
 const s=S[i];$('ct').textContent=s.n+': weekly demand and forecast';$('ch').innerHTML=lc([{d:s.d.slice(-52),c:'var(--mu)',w:1.5},{d:[s.d[103],...s.f],c:'var(--ac)',w:2.5,dash:1,o:51}]);
 const tot=S.reduce((a,x)=>a+x.rev,0);let cum=0;const O=S.map(x=>x).sort((a,b)=>b.rev-a.rev).map(x=>{cum+=x.rev;x.abc=cum/tot<=.7?'A':cum/tot<=.9?'B':'C';return x});
 const T=S.map(x=>{const L=x.LT,fl=x.f.slice(0,L).reduce((a,b)=>a+b,0)+(L>8?0:0),rop=fl+z*x.sg*Math.sqrt(L),fl1=x.f.slice(0,Math.min(8,L+1)).reduce((a,b)=>a+b,0),tg=fl1+z*x.sg*Math.sqrt(L+1),pos=x.oh+x.oo;
  const need=pos<=rop?Math.ceil(tg-pos):0,ex=pos>tg*1.8?Math.round(pos-tg*1.3):0;return{x,rop,tg,pos,need,ex,st:need?'Order':ex?'Excess':'OK',cov:x.oh/mean(x.d.slice(-8))}});
 const ov=T.reduce((a,t)=>a+t.need*t.x.cost,0),xv=T.reduce((a,t)=>a+t.ex*t.x.cost,0);
 $('kpi').innerHTML=kp([['SKUs to reorder now',T.filter(t=>t.need).length,'neg'],['Order value','$'+Math.round(ov).toLocaleString()],['Excess stock value','$'+Math.round(xv).toLocaleString(),xv>0?'neg':'pos'],['Yearly cost of carrying that excess','$'+Math.round(xv*hc).toLocaleString()]]);
 $('tbl').innerHTML=tb(['SKU','Class','Weeks of cover','Lead time (wk)','Stock + on order','Reorder point','Order-up-to','Decision','Quantity'],T.map(t=>[t.x.n,t.x.abc,t.cov.toFixed(1),t.x.LT,Math.round(t.pos),Math.round(t.rop),Math.round(t.tg),'<span class="chip '+(t.st=='Order'?'Cut':t.st=='Excess'?'Hold':'Scale')+'">'+t.st+'</span>',t.need?'order '+t.need:t.ex?'surplus '+t.ex:'-']));
 const o=T.filter(t=>t.need).map(t=>t.x.n),e=T.filter(t=>t.ex).map(t=>t.x.n);
 $('ac').innerHTML=ul([o.length?'<b>Reorder now: '+o.join(', ')+'.</b> Stock plus orders sit below the point needed to cover lead-time demand at '+Math.round(p*100)+'% service.':'Nothing is below its reorder point.',e.length?'<b>Stop buying and mark down: '+e.join(', ')+'.</b> Stock is far above the order-up-to level.':'No SKU is badly overstocked.','Safety stock scales with forecast error and lead time, so reduce error or shorten lead time to cut inventory without raising stockout risk.','Review class A SKUs weekly and class C monthly.'])}
sel.onchange=run;['sl','hc'].forEach(i=>$(i).oninput=run);run();
/* AI optimizer */
function erf(x){const t=1/(1+.3275911*Math.abs(x)),y=1-(((((1.061405429*t-1.453152027)*t)+1.421413741)*t-.284496736)*t+.254829592)*t*Math.exp(-x*x);return x<0?-y:y}
function OPT(a){const hc=+$('hc').value/100;let b=null;for(let p=85;p<=99;p++){const z=zf(p/100);let tot=0;S.forEach(x=>{const sg=x.sg*Math.sqrt(x.LT),ph=Math.exp(-z*z/2)/Math.sqrt(2*Math.PI),Ls=sg*(ph-z*(1-.5*(1+erf(z/Math.SQRT2))));tot+=z*sg*x.cost*hc+(52/x.LT)*Ls*x.cost*.4});if(!b||tot<b.t)b={p,t:tot}}
$('optout').innerHTML='Lowest total cost at a <b>'+b.p+'% service level</b> (about $'+Math.round(b.t).toLocaleString()+' a year in holding plus shortage cost, assuming a lost unit costs 40% of its price).';if(a){$('sl').value=b.p;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
