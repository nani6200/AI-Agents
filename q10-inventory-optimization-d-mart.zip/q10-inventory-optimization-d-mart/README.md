# Q10. Inventory Optimization (D-Mart)
**Problem:** Stockouts on fast sellers while slow sellers pile up.
**Data:** 8 SKUs × 104 weeks of demand with trend and seasonality.
**Algorithm: seasonal forecast + reorder point**
1. Forecast next 8 weeks = demand in the same week last year × trend ratio (mean of last 8 weeks ÷ the same weeks a year ago, clamped to 0.7-1.4).
2. Forecast error σ from 26 weeks of back-tested residuals.
3. ABC class by cumulative revenue (A up to 70%, B up to 90%).
4. Safety stock = `z × σ × √lead time`, with z from the service level (approximation `z ≈ 4.91 (p^0.14 - (1-p)^0.14)`).
5. Reorder point = forecast demand over the lead time + safety stock. If stock on hand + on order ≤ reorder point, order up to target (one period longer); flag Excess if position > 1.8 × target.
6. **Optimizer:** sweep service level 85%-99%; total cost = holding of safety stock + shortage cost, where expected shortage per cycle is `σ_L (φ(z) - z(1-Φ(z)))` and a lost unit costs 40% of its price.

**Code:** `backend/problems/q10.js` (demand, forecast, σ); reorder logic and cost sweep in `app.js`.


**AI component:** Seasonal forecast + service-level cost optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q10.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q10-inventory-optimization-d-mart-standalone.html` also opens directly in a browser with no server.
