import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {D,M,w,am,hm,pk,ST,LAM}=await (await fetch('/api/q07/model')).json();
const f=h=>w[0]+w[1]*(h-40)+w[2]*(h-40)**2+w[3]*am;
function sc(){const W=640,H=250,p=40,X=h=>p+(h-34)/30*(W-p-10),Y=o=>H-26-(o-50)/70*(H-40);let g='<svg viewBox="0 0 '+W+' '+H+'" width="100%"><line x1="'+p+'" x2="'+(W-8)+'" y1="'+(H-26)+'" y2="'+(H-26)+'" stroke="var(--ln)"/>';
 [40,45,50,55,60].forEach(h=>g+='<text x="'+X(h)+'" y="'+(H-8)+'" font-size="11" fill="var(--mu)" text-anchor="middle">'+h+'h</text>');
 D.forEach(d=>g+='<circle cx="'+X(d.h)+'" cy="'+Y(d.o)+'" r="3" fill="var(--mu)" opacity=".5"/>');
 let pts='';for(let h=36;h<=62;h+=1)pts+=X(h)+','+Y(f(h))+' ';g+='<polyline fill="none" stroke="var(--ac)" stroke-width="3" points="'+pts+'"/>';
 g+='<line x1="'+X(pk)+'" x2="'+X(pk)+'" y1="10" y2="'+(H-26)+'" stroke="var(--ac)" stroke-dasharray="4 3"/><text x="'+(X(pk)+4)+'" y="18" font-size="11" fill="var(--ac)">best: '+pk.toFixed(0)+'h</text>';
 const t=+$('hr').value;g+='<line x1="'+X(t)+'" x2="'+X(t)+'" y1="10" y2="'+(H-26)+'" stroke="var(--dn)" stroke-dasharray="4 3"/><text x="'+(X(t)+4)+'" y="32" font-size="11" fill="var(--dn)">test: '+t+'h</text>';return g+'</svg>'}
function run(){const t=+$('hr').value,cp=+$('cp').value/100;$('hv').textContent=t+' hours';$('cv').textContent='+'+Math.round(cp*100)+'%';$('sc').innerHTML=sc();
 const gain=(f(Math.min(pk,hm))-f(hm))/f(hm)*100;
 const S=ST.map(s=>({n:s[0],mu:s[1]}));const bi=S.map(s=>LAM/s.mu).indexOf(Math.max(...S.map(s=>LAM/s.mu)));S[bi].mu*=1+cp;
 S.forEach(s=>{s.rho=LAM/s.mu;s.w=s.rho<.98?1/(s.mu-LAM)*8:99});const tot=S.reduce((a,s)=>a+s.w,0);
 $('st').innerHTML=S.map((s,i)=>row(s.n,s.rho*100,100,Math.round(s.rho*100)+'% busy, wait '+(s.w>=99?'huge':s.w.toFixed(1)+' h'),s.rho>.88?'n':'b')).join('')+'<p class="note">Busy = tasks arriving per day divided by tasks the stage can finish. Waiting time climbs steeply above about 85%. End-to-end time: '+(tot>=99?'unbounded':tot.toFixed(1)+' working hours')+'.</p>';
 $('kpi').innerHTML=kp([['Average hours / week',hm.toFixed(0)],['Output-maximizing hours',pk.toFixed(0)],['Output at test target',f(t).toFixed(0)+' vs '+f(hm).toFixed(0)+' now',f(t)>=f(hm)?'pos':'neg'],['Output gain if hours move to the peak','+'+(gain>0?gain.toFixed(1):'0')+'%'],['Busiest stage',ST[bi][0]]]);
 $('rc').innerHTML=ul(['Hours above about '+pk.toFixed(0)+' per week cost output: the curve falls, so extra hours add cost without adding work done.','Absence is a leading signal: each extra point of absence cuts output by about '+Math.abs(w[3]).toFixed(1)+'. Treat rising absence as a warning before output falls.','Relieve <b>'+ST[bi][0]+'</b> first. It is the busiest stage, so its queue sets the pace for everything after it.','Use the slider to find how much capacity brings every stage under 85% busy.'])}
['hr','cp'].forEach(i=>$(i).oninput=run);run();
/* AI optimizer */
function OPT(a){const h=Math.max(36,Math.min(62,Math.round(pk))),bi=ST.map(s=>LAM/s[1]).indexOf(Math.max(...ST.map(s=>LAM/s[1])));const cp=Math.max(0,Math.min(30,Math.ceil((LAM/(.85*ST[bi][1])-1)*100)));
$('optout').innerHTML='Set weekly hours near <b>'+h+'</b> (output peaks there). Add about <b>'+cp+'%</b> capacity at <b>'+ST[bi][0]+'</b> to bring it under 85% busy.';if(a){$('hr').value=h;$('cp').value=cp;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
