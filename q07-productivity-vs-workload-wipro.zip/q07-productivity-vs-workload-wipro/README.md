# Q7. Productivity vs. Workload (Wipro)
**Problem:** Hours up, output down; where do extra hours stop paying and which stage is the bottleneck?
**Data:** 180 team-weeks (hours 36-62, absence, output).
**Algorithm: quadratic regression + queueing**
1. OLS: `output = a + b1(h-40) + b2(h-40)² + b3×absence`.
2. Peak hours `h* = 40 - b1/(2×b2)`; gain from working at `min(h*, today)` vs today computed at average absence.
3. Workflow of six stages with service rates μ and arrival rate λ = 18 tasks/day. Utilisation `ρ = λ/μ`. Waiting time `≈ 8 / (μ - λ)` hours (single-line queue), unbounded as ρ→1.
4. Bottleneck = stage with the highest ρ; adding capacity multiplies its μ.
5. **Optimizer:** weekly hours = round(h*); capacity add = `ceil((λ/(0.85 μ) - 1) × 100)%` to keep the bottleneck under 85% busy.

**Code:** regression in `backend/problems/q07.js`; queue and chart in `app.js`.


**AI component:** Quadratic regression + queueing bottleneck optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q07.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q07-productivity-vs-workload-wipro-standalone.html` also opens directly in a browser with no server.
