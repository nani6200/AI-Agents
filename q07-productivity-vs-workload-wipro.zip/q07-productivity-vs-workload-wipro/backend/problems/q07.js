// Q7: Employee Productivity vs. Workload - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const r=R(33),D=[];for(let i=0;i<180;i++){const h=36+r()*26,a=Math.max(0,3+N(r)*2+(h-40)*.08),o=100+(h-40)*3-.33*(h-40)**2-2.2*a+N(r)*6;D.push({h,a,o})}
const M=ols(D.map(d=>[d.h-40,(d.h-40)**2,d.a]),D.map(d=>d.o)),w=M.w,am=mean(D.map(d=>d.a)),hm=mean(D.map(d=>d.h)),pk=40-w[1]/(2*w[2]);
const ST=[['Intake',26],['Review',21],['Approval',19.5],['Build',22],['QA',20],['Release',30]],LAM=18;
return {D,M,w,am,hm,pk,ST,LAM};
}
