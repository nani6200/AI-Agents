import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {NM,SL,H,thr,M,DM}=await (await fetch('/api/q09/model')).json();
const sel=$('mc');sel.innerHTML=NM.map((n,i)=>'<option value="'+i+'">'+n+'</option>').join('');
function plan(m,dc,pr,br){if(m.rul>=30)return null;const lim=Math.max(1,Math.min(29,Math.floor(m.rul-2)));let b=0;for(let t=0;t<=lim;t++)if(DM[t]<DM[b])b=t;
 const pc=pr+4*dc*DM[b]/100,fc=br+24*dc*(m.rul>=1?DM[Math.min(29,Math.floor(m.rul))]/100:1);return{day:b+1,pc,fc,urgent:m.rul<4}}
function run(){const i=+sel.value,dc=+$('dc').value,pr=+$('pr').value,br=+$('br').value,m=M[i];
 $('ct').textContent=m.n+': vibration trend and remaining life';
 const pj=[];const n=Math.min(40,m.rul>=999?30:Math.ceil(m.rul)+3);for(let t=0;t<=n;t++)pj.push(m.c+m.b*t);
 $('ch').innerHTML=lc([{d:m.d,c:'var(--mu)',w:1.5},{d:pj,c:'var(--ac)',w:2.5,dash:1,o:H-1}],{L:[{y:thr,t:'failure level',c:'var(--dn)'}],min:0,max:Math.max(9,...m.d)});
 const mxd=Math.max(...DM);$('ld').innerHTML='<div style="display:flex;gap:2px;align-items:end;height:50px;margin-top:6px">'+DM.map((v,t)=>'<div title="day '+(t+1)+'" style="flex:1;height:'+v/mxd*100+'%;background:'+(plan(m,dc,pr,br)&&plan(m,dc,pr,br).day==t+1?'var(--ac)':'var(--ln)')+'"></div>').join('')+'</div>';
 const P=M.map(q=>({q,p:plan(q,dc,pr,br)})),act=P.filter(x=>x.p),pc=act.reduce((a,x)=>a+x.p.pc,0),fc=act.reduce((a,x)=>a+x.p.fc,0);
 $('kpi').innerHTML=kp([['Need service within 30 days',act.length+' of '+M.length],['Planned cost','$'+Math.round(pc).toLocaleString()],['Cost if run to failure','$'+Math.round(fc).toLocaleString()],['Saving','$'+Math.round(fc-pc).toLocaleString(),fc>pc?'pos':'neg']]);
 $('tbl').innerHTML=tb(['Machine','Vibration now','Rising per day','Days to failure level','Health','Best service day','Planned cost $','Breakdown cost $'],P.map(x=>[x.q.n,x.q.c.toFixed(1),x.q.b>.015?'+'+x.q.b.toFixed(2):'flat',x.q.rul>=999?'stable':x.q.rul.toFixed(0),'<span class="chip '+(x.q.rul<10?'Cut':x.q.rul<30?'Hold':'Scale')+'">'+(x.q.rul<10?'Urgent':x.q.rul<30?'Schedule':'Healthy')+'</span>',x.p?'day '+x.p.day+(x.p.urgent?' (urgent)':''):'none needed',x.p?Math.round(x.p.pc).toLocaleString():'-',x.p?Math.round(x.p.fc).toLocaleString():'-']));
 const u=act.filter(x=>x.p.urgent).map(x=>x.q.n);$('ac').innerHTML=ul([u.length?'<b>Service tomorrow: '+u.join(', ')+'.</b> Less than 4 days of life left.':'No machine needs emergency service.','Each service is placed on the lowest-load day before the machine reaches the failure level, with a 2 day safety margin, so lost output is smallest.','Healthy machines are left alone: servicing on a fixed calendar would add cost without reducing failures.','Add temperature and current readings as extra signals once you have failure records to train on.'])}
sel.onchange=run;['dc','pr','br'].forEach(i=>$(i).oninput=run);run();
/* AI optimizer */
function OPT(a){const dc=+$('dc').value,pr=+$('pr').value,br=+$('br').value;const L=M.map(q=>({q,p:plan(q,dc,pr,br)})).filter(x=>x.p).map(x=>({n:x.q.n,s:(x.p.fc-x.p.pc)/Math.max(1,x.q.rul),d:x.p.day})).sort((a,b)=>b.s-a.s);
$('optout').innerHTML=L.length?'Service order: '+L.map((x,i)=>(i+1)+'. <b>'+x.n+'</b> (day '+x.d+')').join(', ')+'. Ranked by cost avoided per day of life left.':'No machine needs service in the next 30 days.'}
$('optbtn').onclick=()=>OPT(true);OPT(false);
