# Q9. Predictive Maintenance (Tata Steel)
**Problem:** Unplanned stoppages.
**Data:** 8 machines × 60 days of vibration; failure level 8 mm/s; 30-day production schedule (weekends lighter).
**Algorithm: trend extrapolation + cheapest service day**
1. Straight-line fit to the last 20 days: slope `b`, current level `c`.
2. Remaining useful life `RUL = (8 - c) / b` if `b > 0.015`, otherwise "no failure in sight".
3. For machines with RUL < 30 days: choose the lowest-load day up to `floor(RUL-2)`.
4. Planned cost = repair cost + 4 hours × downtime cost × load on that day; failure cost = breakdown cost + 24 hours × downtime cost × load on the failure day. Urgent if RUL < 4.
5. **Optimizer:** rank machines by `(failure cost - planned cost) / max(1, RUL)`: money saved per day of life left.

**Code:** vibration data and RUL in `backend/problems/q09.js`; planner in `app.js`.


**AI component:** Trend-based remaining-life model + service-order ranking

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q09.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q09-predictive-maintenance-tata-steel-standalone.html` also opens directly in a browser with no server.
