// Q9: Predictive Maintenance - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const NM=['Hot strip mill','Blast furnace blower','Coke oven pusher','Sinter conveyor','Cold rolling mill','Galvanizing line','Slab caster','Oxygen plant'],SL=[0,.01,.04,.07,.11,.02,.05,.14],r=R(9),H=60,thr=8;
const M=NM.map((n,i)=>{const d=[];for(let t=0;t<H;t++)d.push(1.8+i*.2+SL[i]*Math.max(0,t-25)+N(r)*.18);
 const x=d.slice(-20),xs=x.map((_,j)=>j),mx=mean(xs),my=mean(x),b=xs.reduce((s,v,j)=>s+(v-mx)*(x[j]-my),0)/xs.reduce((s,v)=>s+(v-mx)**2,0),c=my+b*(19-mx);
 return{n,d,b,c,rul:b>.015?Math.max(0,(thr-c)/b):999}});
const DM=Array.from({length:30},(_,t)=>{const dow=(t+2)%7;return Math.round((dow>=5?55:100)+(r()<.15?25:0)+N(r)*4)});
return {NM,SL,H,thr,M,DM};
}
