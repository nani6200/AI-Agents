# Q4. AI Customer Segmentation (Myntra)
**Problem:** Demographic groups make campaigns wasteful.
**Data:** 600 customers from five hidden behaviour types; features: days since last order, orders/year, spend/year, discount share, average basket.
**Algorithm: k-means clustering**
1. Standardize each feature (z-scores).
2. Initialise centres with farthest-point seeding: first centre = first customer; each next centre = the customer farthest (squared distance) from all existing centres.
3. Run 30 iterations of: assign each customer to the nearest centre; move each centre to the mean of its members.
4. Inertia (total squared distance to centres) is computed for K = 2..7 (elbow chart).
5. Segment names from the centre's z-scores: Champions (high spend and frequency), Deal seekers (high discount share), Lapsing (high recency), Low-engagement (low frequency and spend), else Steady regulars. Each has a templated strategy.
6. **Optimizer:** pick the first K where the next inertia drop is less than 40% of the previous drop (default 6).

**Code:** `backend/problems/q04.js` (`km` for K=2..7, results cached); naming and rendering in `app.js`.


**AI component:** k-means clustering + elbow-based choice of K

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q04.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q04-ai-customer-segmentation-myntra-standalone.html` also opens directly in a browser with no server.
