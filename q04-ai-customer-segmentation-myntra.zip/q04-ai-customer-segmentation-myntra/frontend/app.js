import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {FN,CE,D,mu,sg,Z,ST,E,KM}=await (await fetch('/api/q04/model')).json();
const el=document,km=K=>KM[K],dist=(a,b)=>a.reduce((s,v,j)=>s+(v-b[j])**2,0);

function run(){const K=+$('kk').value;$('kv').textContent=K;const M=km(K),S=[];
 for(let i=0;i<K;i++){const idx=M.L.map((l,j)=>l==i?j:-1).filter(j=>j>=0);if(!idx.length)continue;const raw=FN.map((_,d)=>mean(idx.map(j=>D[j][d]))),z=M.C[i];
  const key=z[2]>.7&&z[1]>.4?'champ':z[3]>.7?'deal':z[0]>.7?'lapse':z[1]<-.3&&z[2]<-.3?'low':'reg';S.push({n:idx.length,raw,z,key,rev:idx.length*raw[2]})}
 const cnt={};S.forEach(s=>{cnt[s.key]=(cnt[s.key]||0)+1;s.name=ST[s.key][0]+(cnt[s.key]>1?' '+cnt[s.key]:'')});S.sort((a,b)=>b.rev-a.rev);
 const tr=S.reduce((s,x)=>s+x.rev,0);
 $('rs').innerHTML=S.map(s=>row(s.name,s.rev,S[0].rev,(s.rev/tr*100).toFixed(0)+'% of revenue')).join('');
 $('el').innerHTML=E.map((v,i)=>row(i+2+' segments',v,E[0],Math.round(v),i+2==K?'n':'g')).join('');
 $('pf').innerHTML=tb(['Segment','Customers','Days since order','Orders / yr','Spend / yr $','Discount %','Basket $','Strategy'],S.map(s=>[s.name,s.n,...s.raw.map(v=>Math.round(v)),ST[s.key][1]]));
 $('br').innerHTML=ul(S.map(s=>'<b>'+s.name+'</b>: '+s.n+' customers ('+(s.n/6).toFixed(0)+'% of base) generating '+(s.rev/tr*100).toFixed(0)+'% of revenue. They spend about $'+Math.round(s.raw[2])+' a year over '+Math.round(s.raw[1])+' orders, and last bought '+Math.round(s.raw[0])+' days ago. '+ST[s.key][1]))}
$('kk').oninput=run;run();
/* AI optimizer */
function OPT(a){let b=6;for(let K=3;K<=6;K++){if((E[K-2]-E[K-1])/(E[K-3]-E[K-2])<.4){b=K;break}}
$('optout').innerHTML='Best number of segments: <b>'+b+'</b>. Past that point extra segments barely improve the fit and are harder to act on.';if(a){$('kk').value=b;run()}}
$('optbtn').onclick=()=>OPT(true);OPT(false);
