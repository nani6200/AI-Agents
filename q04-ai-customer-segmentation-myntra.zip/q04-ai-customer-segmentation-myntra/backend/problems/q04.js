// Q4: AI Customer Segmentation - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const r=R(21),FN=['Days since last order','Orders per year','Spend per year ($)','Discount share %','Avg basket ($)'];
const CE=[[20,14,1400,8,100],[35,6,420,55,70],[160,2,150,30,75],[15,3,300,12,100],[60,7,650,25,95]];
const D=[];for(let i=0;i<600;i++){const c=CE[Math.floor(r()*5)];D.push(c.map((v,j)=>Math.max(1,v*(1+N(r)*.22))))}
const mu=FN.map((_,j)=>mean(D.map(d=>d[j]))),sg=FN.map((_,j)=>sd(D.map(d=>d[j]))),Z=D.map(d=>d.map((v,j)=>(v-mu[j])/sg[j]));
const dist=(a,b)=>a.reduce((s,v,j)=>s+(v-b[j])**2,0);
function km(K){let C=[Z[0]];while(C.length<K){let b=-1,bi=0;Z.forEach((z,i)=>{const m=Math.min(...C.map(c=>dist(z,c)));if(m>b){b=m;bi=i}});C.push(Z[bi])}
 let L=[];for(let t=0;t<30;t++){L=Z.map(z=>{let b=1e9,bi=0;C.forEach((c,i)=>{const d=dist(z,c);if(d<b){b=d;bi=i}});return bi});C=C.map((c,i)=>{const m=Z.filter((_,j)=>L[j]==i);return m.length?c.map((_,d)=>mean(m.map(z=>z[d]))):c})}
 return{C,L,I:Z.reduce((s,z,i)=>s+dist(z,C[L[i]]),0)}}
const ST={champ:['Champions','Reward and retain: early access, VIP tier, referral perks. Avoid discounts.'],deal:['Deal seekers','Use targeted promotions and clearance alerts; protect margin with minimum baskets.'],lapse:['Lapsing customers','Win-back series with a reason to return; cap spend per customer.'],low:['Low-engagement','Low-cost nurture: content and one cross-sell prompt.'],reg:['Steady regulars','Grow basket size with bundles and replenishment reminders.']};
const KM={};[2,3,4,5,6,7].forEach(K=>{KM[K]=km(K)});const E=[2,3,4,5,6,7].map(K=>KM[K].I);
return {FN,CE,D,mu,sg,Z,ST,E,KM};
}
