import {$,k,R,N,sig,mean,sd,fm,logit,pred,auc,solve,ols,corr,row,kp,tb,ul,lc} from '../shared/utils.js';
// Model (dataset + fitted parameters) comes from the backend
const {NM,W,LAM,S}=await (await fetch('/api/q08/model')).json();
const sel=$('sp');sel.innerHTML=NM.map((n,i)=>'<option value="'+i+'">'+n+'</option>').join('');
function run(){const i=+sel.value,x=+$('dl').value,pc=+$('pc').value;$('dv').textContent=x+' days';const s=S[i];
 $('ct').textContent=s.n+': lead time by week (days)';$('ch').innerHTML=lc([{d:s.d,c:'var(--mu)',w:1.5},{d:s.E,c:'var(--ac)',w:3}],{L:[{y:s.ucl,t:'alarm level',c:'var(--dn)'},{y:s.base,t:'normal',c:'var(--mu)'}]});
 const T=S.map((q,j)=>{const ex=q.cur-q.base,sh=Math.max(0,ex+(j==i?x:0)-q.buf);return{q,ex,sh,cost:sh*pc,tier:q.al>=0&&sh>0?'Red':q.al>=0||sh>0?'Amber':'Green'}});
 const tot=T.reduce((a,t)=>a+t.cost,0);
 $('kpi').innerHTML=kp([['Suppliers on alarm',S.filter(q=>q.al>=0).length,'neg'],['Earliest warning',S.filter(q=>q.al>=0).map(q=>'week '+(q.al+1)).join(', ')||'none'],['Production days at risk',T.reduce((a,t)=>a+t.sh,0).toFixed(1)],['Exposure',k(tot),tot>0?'neg':'pos']]);
 $('tbl').innerHTML=tb(['Supplier','Normal (days)','Now (days)','Extra delay','Safety buffer (days)','Alarm raised','Days of production at risk','Risk'],T.map(t=>[t.q.n,t.q.base.toFixed(1),t.q.cur.toFixed(1),(t.ex>=0?'+':'')+t.ex.toFixed(1),t.q.buf,t.q.al>=0?'week '+(t.q.al+1):'no',t.sh.toFixed(1),'<span class="chip '+(t.tier=='Red'?'Cut':t.tier=='Amber'?'Hold':'Scale')+'">'+t.tier+'</span>']));
 const rd=T.filter(t=>t.tier=='Red').map(t=>t.q.n),am=T.filter(t=>t.tier=='Amber').map(t=>t.q.n);
 $('mt').innerHTML=ul([rd.length?'<b>Act now ('+rd.join(', ')+')</b>: delay exceeds the buffer. Expedite open orders, activate a backup supplier and add safety stock.':'No supplier currently has delay beyond its buffer.',am.length?'<b>Watch closely ('+am.join(', ')+')</b>: raise safety stock by the extra delay and hold a weekly supplier call.':'No amber suppliers.','Alarms fire on the smoothed trend, so they appear weeks before a missed delivery would show in on-time rates.','Rerun the test with different delays to size the safety stock you need for each supplier.'])}
sel.onchange=run;$('dl').oninput=run;$('pc').oninput=run;run();
/* AI optimizer */
function OPT(a){const x=+$('dl').value,pc=+$('pc').value,hold=pc*.06;const R=S.map(q=>{const need=Math.max(0,(q.cur-q.base)+x-q.buf);return{n:q.n,add:Math.ceil(need),av:need*pc,c:Math.ceil(need)*hold}}).filter(r=>r.add>0);
$('optout').innerHTML=R.length?'To absorb a '+x+'-day disruption, add buffer: '+R.map(r=>'<b>'+r.n+'</b> +'+r.add+' days').join(', ')+'. Holding it costs about '+k(R.reduce((s,r)=>s+r.c,0))+' versus '+k(R.reduce((s,r)=>s+r.av,0))+' of production at risk (assumes a buffer day costs 6% of a lost production day).':'Current buffers already cover a '+x+'-day disruption for every supplier.'}
$('optbtn').onclick=()=>OPT(true);OPT(false);
