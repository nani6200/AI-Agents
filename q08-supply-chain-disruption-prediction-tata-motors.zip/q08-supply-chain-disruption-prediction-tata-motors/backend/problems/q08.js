// Q8: Supply Chain Disruption Prediction - data generation + model fitting (runs once, cached)
import {R,N,sig,mean,sd,logit,pred,auc,solve,ols,corr} from '../lib/stats.js';

export function buildModel(){
const NM=['Steel coil supplier','ECU electronics supplier','Castings supplier','Tyre supplier','Seat supplier','Wiring harness supplier'],r=R(77),W=40,LAM=.3;
const S=NM.map((n,i)=>{const b=12+i*3,d=[];for(let t=0;t<W;t++){let v=b+N(r)*1.2;if(i==1&&t>=24)v+=(t-23)*.38;if(i==3&&t>=32)v+=4.2;if(i==5&&t>=28)v+=(t-27)*.2;d.push(Math.max(2,v))}
 const base=mean(d.slice(0,20)),sg=sd(d.slice(0,20));let e=base;const E=d.map(v=>e=LAM*v+(1-LAM)*e),ucl=base+3*sg*Math.sqrt(LAM/(2-LAM)),al=E.findIndex(v=>v>ucl);
 return{n,d,E,base,ucl,al,buf:3+Math.round(r()*9),cur:E[W-1]}});
return {NM,W,LAM,S};
}
