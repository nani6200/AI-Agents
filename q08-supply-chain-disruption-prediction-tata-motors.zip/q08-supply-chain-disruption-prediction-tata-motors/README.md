# Q8. Supply Chain Disruption Prediction (Tata Motors)
**Problem:** Delays are spotted too late.
**Data:** 6 suppliers × 40 weeks of lead times; three are drifting.
**Algorithm: EWMA control chart + buffer arithmetic**
1. Baseline mean and standard deviation from the first 20 weeks.
2. `E_t = 0.3 × x_t + 0.7 × E_(t-1)`, starting at the baseline mean.
3. Upper control limit `UCL = base + 3σ√(λ/(2-λ))`; alarm week = first week with `E_t > UCL`.
4. Excess delay = current EWMA - baseline. Shortfall days = `max(0, excess + tested disruption - safety buffer days)`; cost = shortfall × daily production loss.
5. Tier: Red if alarm and shortfall, Amber if either, Green otherwise.
6. **Optimizer:** extra buffer days = `ceil(max(0, excess + disruption - buffer))`; holding cost is assumed to be 6% of a lost production day per buffer day.

**Code:** `backend/problems/q08.js` (EWMA, UCL, alarm); tiers and buffers in `app.js`.


**AI component:** EWMA control-chart anomaly detection + buffer optimizer

**Files:** `index.html` (layout), `style.css`, `app.js` (interaction + optimizer). Backend: `backend/problems/q08.js`. 

## Run
```bash
cd backend
npm start      # or: node server.js (Node 18+)
```
Open http://localhost:3000. The file `q08-supply-chain-disruption-prediction-tata-motors-standalone.html` also opens directly in a browser with no server.
